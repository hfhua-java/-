<html>
    <head>
        <style>
            html, body{
                -webkit-tap-highlight-color: transparent;
                -webkit-touch-callout: none;
                -webkit-user-select: none;
                height:100%;
                width:100%;
                margin:0;
                padding:0;
                overflow:hidden;
                user-select:none;
                background-color: rgba(238,238,238,1);
                /*background-color: rgba(245,245,220,1);*/
            }
            a{
                text-decoration: none;
            }
        </style>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="//icon.haoyemao.com/iconfont.css">
        <link rel="stylesheet" href="//at.alicdn.com/t/font_3250367_9neg1ddnm6n.css">
        <link rel="stylesheet" href="../assets/index/css/msg.css">
        <link rel="stylesheet" href="../assets/index/css/findback_code.css">
        <link rel="stylesheet" href="../assets/index/css/findback.css">
        
        <!--短信验证码的js文件-->
        <script type="text/javascript" src="../assets/index/js/haoyemao-code.js"></script>
        <script type="text/javascript" src="../assets/index/js/haoyemao-ecode.js"></script>
        <script type="text/javascript" src="../assets/index/js/haoyemao-pcode.js"></script>
        
        <script type="text/javascript" src="../assets/index/js/jquery.cookie.js"></script>
        <script type="text/javascript" src="../assets/index/js/ajax.js"></script>
		<script type="text/javascript" src="../assets/index/js/msg.js"></script>
		<script type="text/javascript" src="../assets/index/js/findback.js"></script>
		
		
    </head>
    <body>
        <!--head_findback.php内容-->
        <header id="header_findback">
            <div class="return_box">
                <span class="test hymicon lq-fanhui"></span>
            </div>
            <div class="progress_box">
                <div class="progress_step"></div>
            </div>
        </header>
        
        <!--form_findback_step1.php内容-->
        <div id="feedback-msg"></div>
        <div id="findback_data_step1">
            <div class="findback_mobilephone">
                <div class="findback_tip"><p>手机验证找回密码</p></div>
                <div  class="findback_input_step1">
                    <span class="area_data">+86</span>
                    <input type="number" id="step1_tele_input_find" placeholder="mobilephone"  />
                    <div class="findback_logo_step1_delet"><span  class="test hymicon lq-chahao1"></span></div>
                </div>
            </div>
            <div class="email_findback"><span class="email_span" id="switch_phone_email">切换为邮箱验证码</span></div>
            
            <div class="next_step">
                <span class="next_form" href="#">Next</span>
            </div>
        </div>
        
        <!--form_findback_step2.php内容-->
        <div id="findback_data_step2">
            <div class="findback_mobilephone">
                <div class="findback_tip"><span>用***********进行找回</span></div>
        
                <div  class="findback_input_step2" >
                    <input type="number" placeholder="identityCode" id="step2_findback_code">
                </div>
                <!--<span class="reg_code">点击发送验证码</span>-->
                <input type="button" id="findback_note_btn" value="获取验证码"/>
            </div>
            
            <div class="next_step">
                <a class="next_form" href="#">Next</a>
            </div>
        </div>
        
        <!--form_findback_step3.php内容-->
        <div id="findback_data_step3">
            <div class="findback_mobilephone">
                <div class="findback_tip"><span>请设置账号密码</span></div>
                <div  class="findback_input_step3" >
                    <input type="password" id="step3_password_findback" placeholder="password" maxlength="16">
                    
                    
                    
                    <div class="findback_logo_step3_delet"><span  class="test hymicon lq-chahao1"></span></div>
                    
                    <div class="find_logo_switch" id="eye"><span  class="test hymicon lq-yincang"></span></div>
                </div>
                <div class="findback_hard">
                    <div class="show">
                        <div  class="findback_hard_lowLevel"></div>
                        <div  class="findback_hard_midLevel"></div>
                        <div  class="findback_hard_finLevel"></div>    
                    </div>
                    
                </div>
                <div class="findback_hard_size">
                    简单:这种程度的密码被盗是早晚的事！
                </div>
            </div>
            <div class="next_step">
                <a class="next_form" href="#">Next</a>
            </div>
        </div>
        
        <!--form_findback_step4.php内容-->
        <div id="findback_data_step4">
            <div class="findback_mobilephone">
                <div class="findback_tip"><span>请再次输入密码</span></div>
                <div  class="findback_input_step4" >
                    <input type="password" placeholder="password" id="step4_password_again_find" maxlength="16">
                    
                    <div class="findback_logo_step4_delet"><span  class="test hymicon lq-chahao1"></span></div>
                    <div class="find_logo_switch" id="eye"><span  class="test hymicon lq-yincang"></span></div>
                </div>
            </div>
            <div class="next_step">
                
                <a class="next_form" href="#">Finish</a>
            </div>
        </div>
        
        
    </body>
</html>