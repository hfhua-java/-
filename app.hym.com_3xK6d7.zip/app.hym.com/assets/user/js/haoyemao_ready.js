$(document).ready(function() {
	/* 全局配置 */
    user_id = null;				//用户ID
    user_info = null;
    close_obj_history = [];		//返回事件堆栈
    temp_close_obj = null;		//临时选择对象
	msg_list = 0;				//消息号标记（循环）
	tab_page = 0;				//脚文件页，0为首页，1为箱子页，2为我的页
    page_now = "to_index";		//当前打开的主页面（待定）
	head_box_open = 0;			//头像隐藏小菜单，0表示关闭
	require_box_open = 0;       //询问框状态
	class_index = 0;            //存放默认类的c_id
	thing_edit_id = -1;         //正在编辑的物品t_id
	edit_class_id = 0;          //正在被编辑的分类的分类id
	thing_type = 7;             //当前物品的类别
	thing_c_id = 0;             //当前物品的分类
	thing_name_key = "";        //当前物品的模糊搜索关键词
	thing_creat = "";           //用于条件搜查，空值表示非通过创建时间搜查，给的参数是一个日				                              期，日期的日为零表示搜索该月的所有，日期的月份为0表示搜索该				                                年的所有，年为0同样表示非通过创建时间搜查）
	page_items = -1;            //返回的条数
	
	thing_safe_num = -1;        //正常的总数目
	thing_alert_num = -1;       //临期的总数目
	thing_danger_num = -1;      //过期的总数目
	
	sort_type = 0;              //排序条件参数（用于排序，0表示无排序即忽视排序，1表示按创				                                  建日期排序，2表示按临期日期排序，3表示按过期日期排序，4表示				                                按剩余数量排序，5按物品名称排序）
	
    sort_method = 0;            //排序方式参数（用于排序，当排序条件参数为0时，忽略改参				                                      数，当排序参数不为0时，改参数值0表示降序，1表示升序）
	//停止加载代码，用于加载框
	stoploadingcode = '<div class="stop">\
                        <span>---加载完毕啦---</span>\
                    </div>';
	//接口地址
	ajax_url = "/ajax/act.php";
	
	/* index页配置 */
	tomorrow_tab = 0;			//明天过期页放大状态，0为关闭
    today_tab = 0;				//今日过期页放大状态，0为关闭
	
	/* mine页配置 */
	mine_safe = 0;				//账号安全页
    mine_set = 0;				//设置页
    mine_help = 0;				//帮助文档页
    soft_info = 0;              //软件信息页
    aboutus = 0;                //关于我们页
    open_edit_avatar = 0;		//修改头像框
    open_edit_name = 0;			//修改昵称
    open_edit_password = 0;		//修改密码
    open_edit_email = 0;		//修改绑定邮箱
    open_edit_phone = 0;		//修改绑定手机
    new_img = 0;				//产生了新的图片
    pinch = null;				//图片的加载盒子
    flag=false;
	
	/* boxlist页 */
    addclass_box_open = 0;		//添加箱子的底部盒状态0为关闭状态
    editclass_box_open = 0;		//编辑箱子状态
	
	/* thingadd页 */
	var date_now = new Date();
    year_now = date_now.getFullYear();	//当前日期
    month_now = date_now.getMonth();	//当前月
    day_now = date_now.getDate();		//当前日
	//生成“-”格式的日期
    y_m_d_now = year_now + "-" + addchar((month_now + 1).toString(),2,'0') + "-" + addchar((day_now).toString(),2,"0");
    classes = [];						//存放该用户的分类
    thingadd_box_open = 0;              //添加物品页状态
	
	/* thinglist页 */
	thinglist_open = 0;
	thinglist_batch_del_box_open = 0;	//批量删除物品的隐藏盒
    thing_detail_box_open = 0;		    //详情盒子状态
    thing_detail_box_open_item = 0;	    //详情盒子中是否有内容打开
    thing_detail_record_open = 0;	    //物品记录打开
    thing_edit_open = 0;			    //物品编辑打开状态
    page = 0;							//页码
    loading_page = 0;                   //加载状态
    class_ajax_add = 0;                 //class_ajax_add状态
    thing_data_isend = 0;				//是否到数据末尾
    things = [];						//存放物品信息数组
    delthings = [];                     //删除物品数组
    thingtodays = [];                   //首页的今日过期
    thingtomorrows = [];                //首页的明日过期
    
	/* thingsearch页 */
	searchlist_open = 0;                
	search_open = 0;					//searchlist打开情况
    search_batch_del_box_open = 0;		//批量删除物品的隐藏盒
    search_box_select_open = 0;         //物品分类开启
	
	/*thingset页*/
	switch_alert_inner = 0;
	switch_alert_email = 0;
	switch_alert_phone = 0;
	edit_avataring = 0;
	clipic = new Clipic();
	/* 加载函数 */
	loadings();
	
	/* 监听事件 */
	//thinglist滚轮监听
	$("#thinglist-box>.list-box").scroll(function(){
        var bh = $("#thinglist-box>.list-box").height();		//body_height
        var bt = $("#thinglist-box>.list-box").offset().top;	//body_top
        var lt = $("#thinglist-loading-box").offset().top;		//loading_top
        if(lt  <= bt + bh - 30){
            //响应事件
            if(page > 0  && loading_page == 0 && thinglist_batch_del_box_open == 0){
                loading_page = 1;
                get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
            }
        }
    });

	//thingsearch滚轮监听
	$("#search-box>.list-box").scroll(function(){
        var bh = $("#search-box>.list-box").height();			//body_height
        var bt = $("#search-box>.list-box").offset().top;		//body_top
        var lt = $("#searchlist-loading-box").offset().top;		//loading_top
        if(lt  <= bt + bh - 30){
            //响应事件
            if(page > 0  && loading_page == 0 && search_batch_del_box_open == 0){
                loading_page = 1;
                get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
            }
        }
    });
	/* 不确定代码 */
	
    /*实现固定面板高度，感觉没用 
	var height = $(".pannel-body").height();
    var div_height = document.getElementsByClassName(".pannel-body");
    var i;
    for (i = 0; i < div_height.length; i++)
    {
        div_height[i].style.height = height+"px";
    } */
});

//截取返回
window.addEventListener("popstate",function(){
    if(close_obj_history.length != 0){
        // alert(close_obj_history[close_obj_history.length - 1]);
        goback(close_obj_history[close_obj_history.length - 1]);
        // $(close_obj_history[close_obj_history.length - 1]).click();
        return false;
    }
},false);

//点击空白区域  
$(document).mouseup(function(e){
    //index页缩小化 
	var target = $('.shrink'); 		//设置目标区域
	var target2 = $('.magnify-box');
	if (!target.is(e.target) && !target2.is(e.target) && target2.has(e.target).length === 0 && target.has(e.target).length === 0 && (tomorrow_tab + today_tab) == 1){
	    $('.shrink').click();
	}
	
	//隐藏菜单隐藏
	target = $('#menu-mini'); 		//设置目标区域
	target2 = $('.avatar-box');
	if (!target.is(e.target) && !target2.is(e.target) && target2.has(e.target).length === 0 && target.has(e.target).length === 0 && head_box_open == 1){
		$('.avatar-box').click();
	}
	
	//隐藏物品添加
	target = $('#addclass-box'); 	//设置目标区域
	if (!target.is(e.target) && target.has(e.target).length === 0 && addclass_box_open == 1){
		$('#addclass-box>.head>.return-box').click();
	}
	
	//隐藏物品详情弹窗
	target = $('#detail-box'); // 设置目标区域
	if (!target.is(e.target) && target.has(e.target).length === 0 && thing_detail_box_open == 1 && thing_detail_box_open_item == 0){
		$('#detail-box>.head>.closebtn').click();
	}
	
	
	//隐藏搜索条件盒子
	target = $('#search-item-box'); // 设置目标区域
	if (!target.is(e.target) && target.has(e.target).length === 0 && search_open == 1 && search_box_select_open == 0){
		$('#search-item-box>.head>.return-box').click();
	}
	
	//mine中的改绑邮箱隐藏小差
	target = $('#edit-email-set').parent(); // 设置目标区域
	if (!target.is(e.target) && target.has(e.target).length === 0 && open_edit_email == 1){
		$("#edit-email-set").parent().children(".clear-btn").css("visibility","hidden");
	}
	else{
	    $("#edit-email-set").parent().children(".clear-btn").css("visibility","visible");
	}
});

// get_class(1,"");