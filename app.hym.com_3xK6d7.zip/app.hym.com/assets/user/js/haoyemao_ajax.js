//添加类别--list.js
function add_class(id, name, beizhu){
    if(name == "全部"){
        add_msg("全部为系统保留，请更换名称",2);
        return 0;
    }
    if(class_ajax_add == 1)return 0;
    $("#loading_page").fadeIn(100);
    class_ajax_add = 1;
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'c_u_id':id,
			'c_name':name,
			'c_remark':beizhu,
			'act':'addclass',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		     switch(data)
            {
                case -1:
                    add_msg("分类已存在",3);
                    break;
                case 0:
                    add_msg("添加失败",3);
                    break;
                default:
                    add_msg("添加成功");
                    addclass_add(data,name,beizhu,0);
                    var c_item = new Object();
                    var i = classes.length + 1;
                    c_item.id = i.toString();
                    c_item.c_id = data;
                    c_item.value = name;
                    c_item.beizhu = beizhu;
                    c_item.num = 0;
                    classes.push(c_item);
                    classselect.updateWheel(0, classes);
                    list_class_select.updateWheel(0, classes);
                    search_box_select.updateWheel(0, classes);
                    if(addclass_box_open){
                        window.history.back();
                    }
                    break;
            }
            class_ajax_add = 0;
            $("#loading_page").fadeOut(100);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(100);
		    add_msg("添加分类接口错误",3);
		    class_ajax_add = 0;
		}
    });
}

//修改类的内容
function edit_class(id, name, beizhu){
    if(classes[get_class_id(id)].value == name && classes[get_class_id(id)].beizhu == beizhu || id == class_index){
        add_msg("内容一样无需更改",2);
        if(addclass_box_open){
            window.history.back();
        }
        return 0;
    }
    //$("#loading_page").fadeIn(300);
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'c_id':id,
			'c_name':name,
			'c_remark':beizhu,
			'act':'editclass',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		     switch(data)
            {
                case 0:
                    add_msg("修改失败",3);
                    break;
                case 1:
                    add_msg("修改成功");
                    //进行滚动更改
                    var t_c_id = classes[get_class_id(id)].c_id;
                    classes[get_class_id(id)].value = name;
                    classes[get_class_id(id)].beizhu = beizhu;
                    addclass_edit(id,name,beizhu,classes[get_class_id(id)].num);
                    classselect.updateWheel(0, classes);
                    list_class_select.updateWheel(0, classes);
                    search_box_select.updateWheel(0, classes);
                    for(var i=0; i < thingtodays.length; i++){
                        if(thingtodays[i].t_c_id == t_c_id){
                            alert_thing_edit(1,thingtodays[i].t_id);
                        }
                    }
                    for(var i=0; i < thingtomorrows.length; i++){
                        if(thingtomorrows[i].t_c_id == t_c_id){
                            alert_thing_edit(0,thingtomorrows[i].t_id);
                        }
                    }
                    if(addclass_box_open){
                        window.history.back();
                    }
                    break;
                default:
                    add_msg("未知的异常",2);
                    break;
            }
            $("#loading_page").fadeOut(300);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(300);
		    add_msg("修改分类接口错误",3);
		}
    });
}

//获取所有类别--thingadd.js
function get_class(id,obj = ""){
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'c_u_id':id,
			'act':'getclass',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data.msg)
            {
                case 0:
                    add_msg("获取失败",3);
                    break;
                case 1:
                    classes = [];
                    for(var i = 1; i<=data.class.length; i++){
                        var c_item = new Object();
                        c_item.id = i.toString();
                        c_item.c_id = data.class[i-1].c_id;
                        c_item.value = data.class[i-1].c_name;
                        c_item.beizhu = data.class[i-1].c_remark;
                        c_item.num = data.class[i-1].c_num;
                        if(c_item.value == "默认")class_index = c_item.c_id;
                        classes.push(c_item);
                    }
                    classselect.updateWheel(0, classes);
                    list_class_select.updateWheel(0, classes);
                    search_box_select.updateWheel(0, classes);
                    if(obj == "boxlist"){
                        search_box_select.updateWheel(0, classes);
                        for(var i = 1; i<=data.class.length; i++){
                            addclass_add(data.class[i-1].c_id,data.class[i-1].c_name,data.class[i-1].c_remark,data.class[i-1].c_num);
                        }
                        $("#boxlist-loading-box").html(stoploadingcode);
                    }
                    break;
                default:
                    add_msg("未知的异常",3);
                    break;
            }
		},
		error:function(data)
		{
		    add_msg("获取分类接口错误!",3);
		}
    });
}
function del_class(c_id){
    if(c_id == class_index){
        add_msg("系统默认分类不可删",3);
        return 0;
    }
    $("#loading_page").fadeIn(300);
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'c_id':c_id,
			'type':class_index,
			'act':'delclass',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		     switch(data)
            {
                case 0:
                    add_msg("删除失败",3);
                    break;
                case 1:
                    add_msg("删除成功");
                    var t_c_id = classes[get_class_id(c_id)].c_id;
                    var def_c_id = classes[get_class_name("默认")].c_id;
                    delclasses(c_id);
                    $("#c_" + c_id).remove();
                    classselect.updateWheel(0, classes);
                    list_class_select.updateWheel(0, classes);
                    search_box_select.updateWheel(0, classes);
                    for(var i=0; i < thingtodays.length; i++){
                        if(thingtodays[i].t_c_id == t_c_id){
                            thingtodays[i].t_c_id = def_c_id;
                            alert_thing_edit(1,thingtodays[i].t_id);
                        }
                    }
                    for(var i=0; i < thingtomorrows.length; i++){
                        if(thingtomorrows[i].t_c_id == t_c_id){
                            thingtomorrows[i].t_c_id = def_c_id;
                            alert_thing_edit(0,thingtomorrows[i].t_id);
                        }
                    }
                    break;
                default:
                    add_msg("未知的异常",3);
                    break;
            }
            $("#loading_page").fadeOut(300);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(300);
		    add_msg("删除分类接口错误",3);
		}
    });
}
function add_thing(t_u_id, t_name, t_num, t_c_id, t_date, t_ddldate, t_alert_day, t_remark){
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_u_id':t_u_id,
			'act':'addthing',
			't_name':t_name,
			't_num':t_num,
			't_c_id':t_c_id,
			't_date':t_date,
			't_ddldate':t_ddldate,
			't_alert_day':t_alert_day,
			't_remark':t_remark
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data)
            {
                case 0:
                    add_msg("添加失败",3);
                    break;
                default:
                    add_msg("添加成功");
                    var t = get_class_id(t_c_id);
                    classes[t].num = classes[t].num + 1;
                    addclass_edit(t_c_id,classes[t].value,classes[t].beizhu,classes[t].num);
                    //更改顶部数量
                    var t1 = "";
                    if(AddDays(t_ddldate, -t_alert_day) > y_m_d_now){
                        t1 = 'type-safe';
                    }
                    else if(t_ddldate < y_m_d_now){
                        t1 = "type-danger";
                    }
                    else{
                        t1 = "type-warn";
                    }
                    $("#thing_alert>.tab-item>.value>." + t1).text(parseInt($("#thing_alert>.tab-item>.value>." + t1).text()) + 1);
                    //增加判断是否删除或添加到首页两个数组中
                    if(thingadd_box_open == 1){
                        window.history.back();
                    }
                    if(t_ddldate == y_m_d_now){
                        var t_item = new Object();
                        t_item.id = (thingtodays.length).toString();
                        t_item.t_id = data;
                        t_item.t_c_id = t_c_id;
                        t_item.t_name = t_name;
                        t_item.t_num = t_num;
                        t_item.t_remark = t_remark;
                        t_item.t_createdate = y_m_d_now;
                        t_item.t_date = t_date;
                        t_item.t_ddldate = t_ddldate;
                        t_item.t_alert_day = t_alert_day;
                        thingtodays.push(t_item);
                        alert_thing_add(1,data);
                    }
                    else if(getDaysBetween(y_m_d_now,t_ddldate) == 1){
                        var t_item = new Object();
                        t_item.id = (thingtomorrows.length).toString();
                        t_item.t_id = data;
                        t_item.t_c_id = t_c_id;
                        t_item.t_name = t_name;
                        t_item.t_num = t_num;
                        t_item.t_remark = t_remark;
                        t_item.t_createdate = y_m_d_now;
                        t_item.t_date = t_date;
                        t_item.t_ddldate = t_ddldate;
                        t_item.t_alert_day = t_alert_day;
                        thingtomorrows.push(t_item);
                        alert_thing_add(0,data);
                    }
                    break;
            }
            $("#loading_page").fadeOut(300);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(300);
		    add_msg("添加物品接口错误",3);
		}
    });
}
function edit_thing(t_id, t_name, t_num, t_c_id, t_date, t_ddldate, t_alert_day, t_remark){
    var id = get_thing_id(t_id);
    if(t_name == things[id].t_name && t_num == things[id].t_num && t_c_id == things[id].t_c_id && things[id].t_date == t_date && things[id].t_ddldate == t_ddldate && t_alert_day == things[id].t_alert_day && things[id].t_remark == t_remark){
        add_msg("和原信息一样，不需修改");
        if(thing_edit_open == 1){
            window.history.back();
        }
        return 0;
    }
    $("#loading_page").fadeIn(300);
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_id':t_id,
			'act':'editthing',
			't_name':t_name,
			't_num':t_num,
			't_c_id':t_c_id,
			't_date':t_date,
			't_ddldate':t_ddldate,
			't_alert_day':t_alert_day,
			't_remark':t_remark,
			'type':"0"
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data)
            {
                case 0:
                    add_msg("修改失败",3);
                    break;
                case 1:
                    add_msg("修改成功");
                    things[id].t_name = t_name;
                    things[id].t_num = t_num;
                    things[id].t_date = t_date;
                    things[id].t_remark = t_remark;
                    if(things[id].t_c_id != t_c_id){
                        var t = get_class_id(things[id].t_c_id);
                        classes[t].num = classes[t].num - 1;
                        addclass_edit(things[id].t_c_id,classes[t].value,classes[t].beizhu,classes[t].num);
                        t = get_class_id(t_c_id);
                        classes[t].num = classes[t].num + 1;
                        addclass_edit(t_c_id,classes[t].value,classes[t].beizhu,classes[t].num);
                    }
                    var t1 = "";
                    var t2 = "";
                    if(AddDays(things[id].t_ddldate, -things[id].t_alert_day) > y_m_d_now){
                        t1 = 'type-safe';
                    }
                    else if(things[id].t_ddldate < y_m_d_now){
                        t1 = "type-danger";
                    }
                    else{
                        t1 = "type-warn";
                    }
                    if(AddDays(t_ddldate, -t_alert_day) > y_m_d_now){
                        t2 = 'type-safe';
                    }
                    else if(t_ddldate < y_m_d_now){
                        t2 = "type-danger";
                    }
                    else{
                        t2 = "type-warn";
                    }
                    $("#thing_alert>.tab-item>.value>." + t1).text(parseInt($("#thing_alert>.tab-item>.value>." + t1).text()) - 1);
                    $("#thing_alert>.tab-item>.value>." + t2).text(parseInt($("#thing_alert>.tab-item>.value>." + t2).text()) + 1);
                    var type = "safe";
                    if(t2 == 'type-danger'){
                        type = "danger";
                    }
                    else if(t2 == "type-warn"){
                        type = "warn";
                    }
                    var n_id = "#t_" + (get_thing_id(things[id].t_id) + 1) + "_" + t_id;
                    var days = getDaysBetween(y_m_d_now,t_ddldate);
                    var classname = classes[get_class_id(t_c_id)].value;
                    thing_edit_card(t_name,n_id,"del_t_" + (get_thing_id(things[id].t_id) + 1),t_name,classname,Math.abs(days),t_num,things[id].t_createdate,t_remark,type);
                    things[id].t_ddldate = t_ddldate;
                    things[id].t_alert_day = t_alert_day;
                    things[id].t_c_id = t_c_id;
                    if(thing_edit_open == 1){
                        window.history.back();
                    }
                    //增加判断是否删除或添加到首页两个数组中
                    if(things[id].t_ddldate == y_m_d_now){
                        if(get_alertthing_id(1, things[id].t_id) == -1){
                            //创造
                            thingtodays.push(things[id]);
                            alert_thing_add(1,things[id].t_id);
                        }
                        else{
                            //更新
                            var id_t = get_alertthing_id(1, things[id].t_id);
                            thingtodays[id_t].t_name = t_name;
                            thingtodays[id_t].t_c_id = t_c_id;
                            thingtodays[id_t].t_num = t_num;
                            alert_thing_edit(1,things[id].t_id);
                        }
                        if(get_alertthing_id(0, things[id].t_id) != -1){
                            //删除
                            alert_thing_del(0,things[id].t_id);
                        }
                    }
                    else{
                        if(get_alertthing_id(1, things[id].t_id) != -1){
                            //删除
                            alert_thing_del(1,things[id].t_id);
                        }
                    }
                    
                    if(days == 1){
                        if(get_alertthing_id(0, things[id].t_id) == -1){
                            //创造
                            thingtomorrows.push(things[id]);
                            alert_thing_add(0,things[id].t_id);
                        }
                        else{
                            //更新
                            var id_t = get_alertthing_id(0, things[id].t_id);
                            thingtomorrows[id_t].t_name = t_name;
                            thingtomorrows[id_t].t_c_id = t_c_id;
                            thingtomorrows[id_t].t_num = t_num;
                            alert_thing_edit(0,things[id].t_id);
                        }
                        if(get_alertthing_id(1, things[id].t_id) != -1){
                            //删除
                            alert_thing_del(1,things[id].t_id);
                        }
                    }
                    else{
                        if(get_alertthing_id(0, things[id].t_id) != -1){
                            //删除
                            alert_thing_del(0,things[id].t_id);
                        }
                    }
                    break;
            }
            $("#loading_page").fadeOut(300);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(300);
		    add_msg("修改物品接口错误",3);
		}
    });
}
function get_thing_num(t_u_id,type){
    if(type > 7)return 0;
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_u_id':t_u_id,
			'act':'getthing',
			't_type':type,
			't_c_id':'0',
			't_name_key':'',
			't_creat':'0000-00-00',
			'sort_type':'0',
			'sort_method':'0',
			'page':'1',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data.msg)
            {
                case 0:
                    add_msg("获取失败",3);
                    break;
                case -1:
                case 1:
                    if(type == 4){
                        $("#thing_alert>.tab-item>.value>.type-safe").text(data.num);
                    }
                    else if(type == 2){
                        $("#thing_alert>.tab-item>.value>.type-warn").text(data.num);
                    }
                    else if(type == 1){
                        $("#thing_alert>.tab-item>.value>.type-danger").text(data.num);
                    }
                    get_thing_num(t_u_id,type * 2);
                    break;
                default:
                    add_msg("未知的异常",3);
                    break;
            }
		},
		error:function(data)
		{
		    add_msg("获取物品数量接口错误",3);
		}
    });
}

function get_thing(t_u_id,t_type,t_c_id,t_name_key,t_creat,sort_type,sort_method,pages){
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_u_id':t_u_id,
			'act':'getthing',
			't_type':t_type,
			't_c_id':t_c_id,
			't_name_key':t_name_key,
			't_creat':t_creat,
			'sort_type':sort_type,
			'sort_method':sort_method,
			'page':pages,
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data.msg)
            {
                case 0:
                    add_msg("获取失败",3);
                    break;
                case -1:
                    if(thinglist_open == 1){
                        loading_end("#thinglist-loading-box");
                    }
                    else if(searchlist_open == 1){
                        loading_end("#searchlist-loading-box");
                    }
                    page = -1;
                case 1:
                    if(page_items == -1){
                        page_items = data.num;
                        if(thinglist_open == 1){
                            $("#thinglist_page_items").text(page_items);
                        }
                    }
                    for(var i = 1; i<=data.thing.length; i++){
                        var t_item = new Object();
                        t_item.id = (i + pages * 10 - 10).toString();
                        t_item.t_id = data.thing[i-1].t_id;
                        t_item.t_c_id = data.thing[i-1].t_c_id;
                        t_item.t_name = data.thing[i-1].t_name;
                        t_item.t_num = data.thing[i-1].t_num;
                        t_item.t_remark = data.thing[i-1].t_remark;
                        t_item.t_createdate = data.thing[i-1].t_createdate;
                        t_item.t_date = data.thing[i-1].t_date;
                        t_item.t_ddldate = data.thing[i-1].t_ddldate;
                        t_item.t_alert_day = data.thing[i-1].t_alert_day;
                        things.push(t_item);
                        var num = getDaysBetween(y_m_d_now,t_item.t_ddldate);
                        if(num > t_item.t_alert_day){
                            type = "safe";
                        }
                        else if(num >= 0){
                            type = "warn";
                        }
                        else{
                            type = "danger";
                        }
                        num = Math.abs(num);
                        if(thinglist_open == 1){
                            list_add_thing(t_item.id,t_item.t_id,t_item.t_name,classes[get_class_id(t_item.t_c_id)].value,num,t_item.t_num,t_item.t_createdate,t_item.t_remark,type,'#thinglist-loading-box');
                        }
                        else if(searchlist_open == 1){
                            list_add_thing(t_item.id,t_item.t_id,t_item.t_name,classes[get_class_id(t_item.t_c_id)].value,num,t_item.t_num,t_item.t_createdate,t_item.t_remark,type,'#searchlist-loading-box');
                        }
                    }
                    break;
                default:
                    add_msg("未知的异常",3);
                    break;
            }
            loading_page = 0;
            $("#loading_page").fadeOut(300);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(300);
		    add_msg("获取物品接口错误",3);
		}
    });
}

function del_thing(char){
    $("#loading_page").fadeIn(200);
    var t_ids="";
    var ids = [];
    for(var i = 0; i < delthings.length; i++){
        t = delthings[i].split("_");
        t_ids = t_ids + t[2] + char;
        ids.push(t[1]); 
    }
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_ids':t_ids,
			'act':'delthing',
			'cuts':char,
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data)
            {
                case 0:
                    add_msg("删除成功");
                    var t1,t2,t3;
                    t1 = 0;
                    t2 = 0;
                    t3 = 0;
                    for(var i = 0; i < delthings.length; i++){
                        var id = "#" + delthings[i];
                        if($(id + ">.card>.head").hasClass("safe"))t1++;
                        if($(id + ">.card>.head").hasClass("warn"))t2++;
                        if($(id + ">.card>.head").hasClass("danger"))t3++;
                        $(id).remove();
                    }
                    var c_id;
                    for(var i = 0; i < ids.length;i++){
                        c_id = things[ids[i] - 1].t_c_id;
                        classes[get_class_id(c_id)].num = classes[get_class_id(c_id)].num - 1;
                        addclass_edit(c_id,classes[get_class_id(c_id)].value,classes[get_class_id(c_id)].beizhu,classes[get_class_id(c_id)].num);
                        //增加判断是否删除或添加到首页两个数组中
                        alert_thing_del(0,things[ids[i] - 1].t_id);
                        alert_thing_del(1,things[ids[i] - 1].t_id);
                    }
                    delthings = [];
                    $("#thing_alert>.tab-item>.value>.type-safe").text(parseInt($("#thing_alert>.tab-item>.value>.type-safe" ).text()) - t1);
                    $("#thing_alert>.tab-item>.value>.type-warn").text(parseInt($("#thing_alert>.tab-item>.value>.type-warn" ).text()) - t2);
                    $("#thing_alert>.tab-item>.value>.type-danger").text(parseInt($("#thing_alert>.tab-item>.value>.type-danger" ).text()) - t3);
                    if(thinglist_batch_del_box_open == 1){
                        window.history.back();
                    }
                    break;
                default:
                    add_msg("删除失败",3);
                    break;
            }
            $("#loading_page").fadeOut(200);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(200);
		    add_msg("删除物品接口错误",3);
		}
    });
}

//首页获取最近过期
function get_thing_alert(u_id,type,page){
    $("#loading_page").fadeIn(200);
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'u_id':u_id,
			'act':'recentthing',
			'type':type,
			'page':page,
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data.msg)
            {   
                case -1:
                    add_msg("获取失败！",3);
                    break;
                case 0:
                    if(page == 1 && data.thing.length == 0){
                        if(type == 1){
                            // $("#today").hide();
                        }
                        else{
                            // $("#tomorrow").hide();
                        }
                    }
                case 1:
                    // alert(JSON.stringify(data.thing));
                    for(var i = 1; i<=data.thing.length; i++){
                        var t_item = new Object();
                        t_item.id = (i + page * 10 - 10).toString();
                        t_item.t_id = data.thing[i-1].t_id;
                        t_item.t_c_id = data.thing[i-1].t_c_id;
                        t_item.t_name = data.thing[i-1].t_name;
                        t_item.t_num = data.thing[i-1].t_num;
                        t_item.t_remark = data.thing[i-1].t_remark;
                        t_item.t_createdate = data.thing[i-1].t_createdate;
                        t_item.t_date = data.thing[i-1].t_date;
                        t_item.t_ddldate = data.thing[i-1].t_ddldate;
                        t_item.t_alert_day = data.thing[i-1].t_alert_day;
                        if(type == 1){
                            //今天过期
                            thingtodays.push(t_item);
                        }
                        else{
                            //明天过期
                            thingtomorrows.push(t_item);
                        }
                        //alert_thing_add(type,data.thing[i-1].t_id);
                    }
                    if(data.msg == 1){
                        get_thing_alert(u_id,type,page+1);
                    }
                    break;
                default:
                    add_msg("未知的异常",3);
                    break;
            }
            $("#loading_page").fadeOut(200);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(200);
		    add_msg("获取最近物品接口错误",3);
		}
    });
}

//处理物品
function pro_thing(t_id,t_change){
    var id = get_thing_id(t_id);
    if(things[id].t_num + t_change < 0){
        add_msg("超出可消耗数量",3);
        return 0;
    }
    if(things[id].t_num + t_change > 1000000){
        add_msg("物品最大数量不可超过1000000",3);
        return 0;
    }
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_id':t_id,
			'act':'editthing',
			't_change':t_change,
			'type':"1"
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data)
            {
                case 0:
                    add_msg("处理失败",3);
                    break;
                case 1:
                    add_msg("处理成功");
                    things[id].t_num = parseInt(things[id].t_num) + parseInt(t_change);
                    $("#t_" + (id + 1) + "_" + t_id + ">.card>.body>.info>.topbox>.num>.v").html((things[id].t_num).toString());
                    $("#detail-box-num").text((things[id].t_num).toString());
                    if(require_box_open == 1){
                        window.history.back();
                    }
                    var days = getDaysBetween(y_m_d_now,things[id].t_ddldate);
                    //增加判断是否删除或添加到首页两个数组中
                    if(things[id].t_ddldate == y_m_d_now){
                        if(get_alertthing_id(1, things[id].t_id) != -1){
                            var id_t = get_alertthing_id(1, things[id].t_id);
                            thingtodays[id_t].t_num = things[id].t_num ;
                            alert_thing_edit(1,things[id].t_id);
                        }
                    }
                    if(days == 1){
                        if(get_alertthing_id(0, things[id].t_id) != -1){
                            var id_t = get_alertthing_id(0, things[id].t_id);
                            thingtomorrows[id_t].t_num = things[id].t_num;
                            alert_thing_edit(0,things[id].t_id);
                        }
                    }
                    //增加判断是否删除或添加到首页两个数组中
                    break;
            }
		},
		error:function(data)
		{
		    add_msg("物品处理接口错误",3);
		}
    });
}

function record_list_get(t_id){
    $("#loading_page").fadeIn(300);
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			't_id':t_id,
			'act':'getrecord',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data.msg)
            {
                case 0:
                    add_msg("获取失败",3);
                    break;
                case 1:
                    add_msg("获取成功");
                    var t = data.operator.length;
                    thing_record_clear();
                    thing_record_num(t);
                    var id = get_thing_id(t_id);
                    thing_record_name(things[id].t_name);
                    for(var i = 0; i < t; i++){
                        thing_record_add(data.operator[i].l_date, data.operator[i].l_time, data.operator[i].l_text);
                    }
                    //增加判断是否删除或添加到首页两个数组中
                    break;
            }
            $("#loading_page").fadeOut(300);
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(300);
		    add_msg("获取物品记录接口错误",3);
		}
    });
}

function get_info(u_id){
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'u_id':u_id,
			'act':'getinfo',
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    switch(data.msg)
            {
                case 0:
                    add_msg("获取用户数据失败",3);
                    break;
                case 1:
                    if(user_info == null){
                        user_info = new Object();
                        user_info.u_id = data.u_id;
                        user_info.u_name = data.u_name;
                        user_info.u_phone = data.u_phone;
                        user_info.u_pwd = data.u_pwd;
                        user_info.u_ip = data.u_ip;
                        user_info.u_reg_date = data.u_reg_date;
                        user_info.u_last_login = data.u_last_login;
                        user_info.u_email = data.u_email;
                        user_info.u_avatar = data.u_avatar;
                        user_info.u_alert_inner = data.u_alert_inner;
                        user_info.u_alert_phone = data.u_alert_phone;
                        user_info.u_alert_email = data.u_alert_email;
                        user_info.u_alert_msg = data.u_alert_msg;
                        users_set("all");
                    }
                    break;
            }
		},
		error:function(data)
		{
		    add_msg("获取用户信息接口错误",3);
		}
    });
}

function edit_info(u_id,key,value){
    $("#loading_page").fadeIn(200);
    $.ajax({  
		type: "POST",   //提交的方法
		url:ajax_url, //提交的地址  
		data:
		{
			'u_id':u_id,
			'act':'editinfo',
			'key':key,
			'value':value,
		},// 序列化表单值  
		dataType : 'json',
		success:function(data) 
		{
		    $("#loading_page").fadeOut(200);
		    switch(data)
            {
                case 0:
                    add_msg("修改失败",3);
                    break;
                case 1:
                    switch(key){
                        case "u_name":
                            add_msg("修改成功");
                            user_info.u_name = value;
                            users_set("name");
                            if(open_edit_name == 1){
                                window.history.back();
                            }
                            break;
                        case "u_pwd":
                            add_msg("修改成功");
                            if(open_edit_password == 1){
                                window.history.back();
                            }
                            $("#edit_user_pwd_1").val("");
                            $("#edit_user_pwd_2").val("");
                            break;
                        case "u_email":
                            add_msg("绑定成功");
                            user_info.u_email = value;
                            $("#edit-email-code").val("");
                            $("#edit-email-set").val("");
                            users_set("email");
                            if(open_edit_email == 1){
                                window.history.back();
                            }
                            break;
                        case "u_phone":
                            add_msg("绑定成功");
                            user_info.u_phone = value;
                            $("#edit-phone-code").val("");
                            $("#edit-phone-set").val("");
                            users_set("phone");
                            if(open_edit_phone == 1){
                                window.history.back();
                            }
                            break;
                        case "u_alert_inner":
                            if(value == 1){
                                add_msg("已打开");
                                user_info.u_alert_inner = "1";
                            }
                            else{
                                add_msg("已关闭");
                                user_info.u_alert_inner = "0";
                            }
                            switch_alert_inner = 0;
                            users_set("inner_thing");
                            break;
                        case "u_alert_phone":
                            if(value == 1){
                                add_msg("已打开");
                            }
                            else{
                                add_msg("已关闭");
                            }
                            switch_alert_phone = 0;
                            break;
                        case "u_alert_email":
                            if(value == 1){
                                add_msg("已打开");
                            }
                            else{
                                add_msg("已关闭");
                            }
                            switch_alert_email = 0;
                            break;
                        case "u_avatar":
                            add_msg("修改成功");
                            edit_avataring = 0;
                            user_info.u_avatar = value;
                            users_set("avatar");
                            if(open_edit_avatar == 1){
                                window.history.back();
                            }
                            break;
                        case 1:
                            //增加判断是否删除或添加到首页两个数组中
                            break;
                    }
                    break;
            }
		},
		error:function(data)
		{
		    $("#loading_page").fadeOut(200);
		    add_msg("修改用户信息接口错误",3);
		}
    });
}