//初始化加载
function loadings(){
    $("#loading_page").fadeIn(300);
    if($.cookie('login_in')){
	    user_id = $.cookie('login_in');
	}
	else{
	    $("#loading_page").fadeOut(300);
	    add_msg("恶意载入",3);
	    setTimeout(function() {window.location.replace("../login.php"); }, 300);//设置信息
	    return 0;
	}
	if(user_id == null){
	    add_msg("加载错误",3);
	    return 0;
	}
    get_info(user_id);
	/* 	index页 */
	//获取物品数目
	get_thing_num(user_id, 1);
	//明日过期滚动卡加载
    tomorrowswiper = new Swiper("#tomorrowcard", {
        grabCursor: true,
        effect: "creative",
        loop: true,
        autoplay: {
            delay: 3000,
            stopOnLastSlide: false,
            disableOnInteraction: false,
            reverseDirection: false,
            pauseOnMouseEnter:true,
        },
        observer:true,//修改swiper自己或子元素时，自动初始化swiper
        observeParents:true,//修改swiper的父元素时，自动初始化swiper
        creativeEffect: {
            prev: {
                shadow: true,
                translate: ["-120%", 0, -500],
            },
            next: {
                shadow: true,
                translate: ["120%", 0, -500],
            },
        },
        onSlideChangeEnd: function(swiper){
        　　swiper.update(); 
            tomorrowswiper.startAutoplay();
        　　tomorrowswiper.reLoop(); 
        },
    });
	
    //今日过期滚动卡加载
    todayswiper = new Swiper("#todaycard", {
        // grabCursor: true,
        effect: "creative",
        loop: true,
        autoplay: {
            delay: 3000,
            stopOnLastSlide: false,
            disableOnInteraction: false,
            reverseDirection: false,
            pauseOnMouseEnter:true,
        },
        observer:true,//修改swiper自己或子元素时，自动初始化swiper
        observeParents:false,//修改swiper的父元素时，自动初始化swiper
        initialSlide :0,
        creativeEffect: {
            prev: {
                shadow: true,
                translate: ["-120%", 0, -500],
            },
            next: {
                shadow: true,
                translate: ["120%", 0, -500],
            },
        },
        onSlideChangeEnd: function(swiper){
        　　swiper.update(); 
            todayswiper.startAutoplay();
        　　todayswiper.reLoop(); 
        },
    });
	
	/* 	thingadd页 */
	dateoption();			//产生日期选项
	dateoption2();          //筛选日期选项
	classselect = new MobileSelect({
        trigger: "#addthing_boxclass",
        title: "选择分类",
        wheels: [
            {data:[{id:'1',value:'请选择分类'},]},
        ],
        position: [0], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {//每一次改动产生的事件
            //console.log(data);
        },
        callback: function (indexArr, data) {
            $('#addthing_boxclass').val(data[0].value);
        },
    });
	
	produce_date = new MobileSelect({
        trigger: "#addthing_produce_date",
        title: "选择生产日期",
        wheels: [
            { data: years},
            { data: months},
            { data: days_31},
        ],
        position: [year_now - 1999,month_now,day_now - 1], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {//每一次改动产生的事件
            var year = indexArr[0] + 1999;
            var month = indexArr[1] + 1;
            var day = indexArr[2] + 1;
            if(month == 2){
                if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
                    produce_date.updateWheel(2, days_29);
                    if(day >= 29){
                        produce_date.locatePosition(2,28);
                    }
                }
                else{
                    produce_date.updateWheel(2, days_28);
                    if(day >= 28){
                        produce_date.locatePosition(2,27);
                    }
                }
            }
            else if((month <= 7 && month % 2 == 1)||(month >= 8 && month % 2 == 0)){
                produce_date.updateWheel(2, days_31);
                if(day >= 31){
                    produce_date.locatePosition(2,30);
                }
            }
            else{
                produce_date.updateWheel(2, days_30);
                if(day >= 30){
                    produce_date.locatePosition(2,29);
                }
            }
        },
        callback: function (indexArr, data) {
            var year = data[0].value;
            var month = data[1].value;
            var day = data[2].value;
            var tymd = year + "-" + month + "-" + day;
            var ttymd = $("#addthing_overdue_date").val();
            if(tymd > ttymd && ttymd != "" || tymd > y_m_d_now){
                add_msg("生产日期不可超过今日！",2);
                produce_date.locatePosition(0,year_now - 1999);
                produce_date.locatePosition(1,month_now);
                produce_date.locatePosition(2,day_now - 1);
                tymd = y_m_d_now;
            }
            $('#addthing_produce_date').val(tymd);
            if(ttymd != ""){
                var t = getDaysBetween(tymd,ttymd);
                $('#addthing_overdue_date_num').val(t);
            }
        },
    });
    
    overdue_date = new MobileSelect({
        trigger: "#addthing_overdue_date",
        title: "选择到期日期",
        wheels: [
            { data: years},
            { data: months},
            { data: days_31},
        ],
        position: [year_now - 1999,month_now,day_now - 1], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {//每一次改动产生的事件
            var year = indexArr[0] + 1999;
            var month = indexArr[1] + 1;
            var day = indexArr[2] + 1;
            if(month == 2){
                if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
                    overdue_date.updateWheel(2, days_29);
                    if(day >= 29){
                        overdue_date.locatePosition(2,28);;
                    }
                }
                else{
                    overdue_date.updateWheel(2, days_28);
                    if(day >= 28){
                        overdue_date.locatePosition(2,27);
                    }
                }
            }
            else if((month <= 7 && month % 2 == 1)||(month >= 8 && month % 2 == 0)){
                overdue_date.updateWheel(2, days_31);
                if(day >= 31){
                    overdue_date.locatePosition(2,30);
                }
            }
            else{
                overdue_date.updateWheel(2, days_30);
                if(day >= 30){
                    overdue_date.locatePosition(2,29);
                }
            }
        },
        callback: function (indexArr, data) {
            var year = data[0].value;
            var month = data[1].value;
            var day = data[2].value;
            var tymd = year + "-" + month + "-" + day;      //过期日期
            var ttymd = $("#addthing_produce_date").val();  //生产日期
            var t;
            var ttnum;                                      //临期提醒天数（可能用到）
            var ttymd2;                                     //临期时间（可能用到）
            if(ttymd == ""){
                add_msg("未设置生产日期，已设为默认值",2);
                ttymd = y_m_d_now;
                $("#addthing_produce_date").val(y_m_d_now);
            }
            if((tymd < ttymd || tymd < y_m_d_now) && thing_edit_open == 0){
                add_msg("不可添加已过期物品！",2);
                overdue_date.locatePosition(0,year_now - 1999);
                overdue_date.locatePosition(1,month_now);
                overdue_date.locatePosition(2,day_now - 1);
                tymd = y_m_d_now;
            }
            $('#addthing_overdue_date').val(tymd);
            if(ttymd != ""){
                t = getDaysBetween(ttymd,tymd);
                $('#addthing_overdue_date_num').val(t);
            }
            
            //临期不合理调整
            if($("#addthing_near_days").val() == ""){
                return 0;
            }
            ttymd2 = $("#addthing_near_date").val();
            ttnum = getDaysBetween(y_m_d_now,tymd);
            if(ttymd2 < ttymd || tymd < ttymd2 || ttymd2 < y_m_d_now){
                add_msg("临期不合理",2);
                if(ttnum > 7){
                    ttnum = 7;
                }
                else if(ttnum > 3){
                    ttnum = 3;
                }
                else{
                    ttnum = 0;
                }
                ttymd2 = AddDays(tymd, -ttnum);
            }
            else{
                return 0;
            }
            t = ttymd2.split('-');
            near_date.locatePosition(0,t[0] - 1999);
            near_date.locatePosition(1,t[1]-1);
            near_date.locatePosition(2,t[2] - 1);
            $('#addthing_near_date').val(ttymd2);
            $('#addthing_near_days').val(ttnum);
        },
    });
	
    near_date = new MobileSelect({
        trigger: "#addthing_near_date",
        title: "选择临期日期",
        wheels: [
            { data: years},
            { data: months},
            { data: days_31},
        ],
        position: [year_now - 1999,month_now,day_now - 1], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {//每一次改动产生的事件
            var year = indexArr[0] + 1999;
            var month = indexArr[1] + 1;
            var day = indexArr[2] + 1;
            if(month == 2){
                if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
                    near_date.updateWheel(2, days_29);
                    if(day >= 29){
                        near_date.locatePosition(2,28);
                    }
                }
                else{
                    near_date.updateWheel(2, days_28);
                    if(day >= 28){
                        near_date.locatePosition(2,27);
                    }
                }
            }
            else if((month <= 7 && month % 2 == 1)||(month >= 8 && month % 2 == 0)){
                near_date.updateWheel(2, days_31);
                if(day >= 31){
                    near_date.locatePosition(2,30);
                }
            }
            else{
                near_date.updateWheel(2, days_30);
                if(day >= 30){
                    near_date.locatePosition(2,29);
                }
            }
        },
        callback: function (indexArr, data) {
            var year = data[0].value;
            var month = data[1].value;
            var day = data[2].value;
            var tymd = year + "-" + month + "-" + day;
            var ttymd = $("#addthing_produce_date").val();
            var ttymd2 = $("#addthing_overdue_date").val();
            var ttnum = $("#addthing_overdue_date_num").val();
            if(ttnum == ""){
                add_msg("请先选择到期时间！",2);
                return 0;
            }
            if(tymd < ttymd || ttymd2 < tymd || tymd < y_m_d_now){
                add_msg("临期不合理",2);
                if(ttnum > 7){
                    ttnum = 7;
                }
                else if(ttnum > 3){
                    ttnum = 3;
                }
                else{
                    ttnum = 0;
                }
                tymd = AddDays(ttymd2, -ttnum);
            }
            else{
                ttnum = getDaysBetween(tymd,ttymd2);
            }
            var t = tymd.split('-');
            near_date.locatePosition(0,t[0] - 1999);
            near_date.locatePosition(1,t[1]-1);
            near_date.locatePosition(2,t[2] - 1);
            $('#addthing_near_date').val(tymd);
            $('#addthing_near_days').val(ttnum);
        },
    });
	
	/* thinglist页 */
    sift = new MobileSelect({
        trigger: "#thing-sift",
        title: "创建时间",
        wheels: [
            { data: years_},
            { data: months_},
            { data: days_31_},
        ],
        position: [0,0,0], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {
            var year = indexArr[0] + 1998;
            var month = indexArr[1];
            var day = indexArr[2];
            if(year == 1998){
                sift.locatePosition(1,0);
                sift.locatePosition(2,0);
                return 0;
            }
            if(month == 0){
                sift.locatePosition(2,0);
                return 0;
            }
            if(month == 2){
                if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
                    near_date.updateWheel(2, days_29);
                    if(day >= 29){
                        near_date.locatePosition(2,28);
                    }
                }
                else{
                    near_date.updateWheel(2, days_28);
                    if(day >= 28){
                        near_date.locatePosition(2,27);
                    }
                }
            }
            else if((month <= 7 && month % 2 == 1)||(month >= 8 && month % 2 == 0)){
                near_date.updateWheel(2, days_31);
                if(day >= 31){
                    near_date.locatePosition(2,30);
                }
            }
            else{
                near_date.updateWheel(2, days_30);
                if(day >= 30){
                    near_date.locatePosition(2,29);
                }
            }
        },
        callback: function (indexArr, data){
            if(thinglist_batch_del_box_open == 1){
                window.history.back();
            }
            if(loading_page == 1)return 0;
            var year = data[0].value;
            var month = data[1].value;
            var day = data[2].value;
            $("#thing-sift").text(year + "-" + month + "-" + day);
            if(year == "不限")year = "0000";
            if(month == "不限")month = "00";
            if(day == "不限")day = "00";
            thing_creat = year + "-" + month + "-" + day;
            page = 0;
            list_clear_thing('#thinglist-box>.list-box','thinglist-loading-box');
            loading_page = 1;
            page_items = -1;
            loading_start("#thinglist-loading-box");
            get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
        },
    });
    
    var sortArr = ["无排序","按创建日期", "按临期日期", "按过期日期", "按剩余数量", "按物品名称"];
    var sortArr_type = ["降序","升序"];
    sort = new MobileSelect({
        trigger: "#thing-sort",
        title: "排序条件",
        wheels: [{ data: sortArr },{ data: sortArr_type}],
        position: [0], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {
            //console.log(data);
        },
        callback: function (indexArr, data) {
            if(thinglist_batch_del_box_open == 1){
                window.history.back();
            }
            if(loading_page == 1)return 0;
            sort_type = indexArr[0];
            sort_method = indexArr[1];
            if(sort_type == 0){
                $("#thing-sort").text(data[0]);
                
            }
            else{
                if(sort_method == 1){
                    $("#thing-sort").text(data[0] + "↑");
                }
                else{
                    $("#thing-sort").text(data[0] + "↓");
                }
            }
            page = 0;
            list_clear_thing('#thinglist-box>.list-box','thinglist-loading-box');
            loading_page = 1;
            page_items = -1;
            loading_start("#thinglist-loading-box");
            get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
        },
    });
    
    list_class_select = new MobileSelect({
        trigger: "#list_class_select",
        title: "选择分类",
        triggerDisplayData:false,
        wheels: [
            {data:[{id:'1',value:'请选择分类'},]},
        ],
        position: [0], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {//每一次改动产生的事件
            //console.log(data);
        },
        callback: function (indexArr, data) {
            if(thinglist_batch_del_box_open == 1){
                window.history.back();
            }
            if(loading_page == 1)return 0;
            $('#list_class_select>.name').text(data[0].value);
            thing_c_id = classes[get_class_name(data[0].value)].c_id;
            page = 0;
            list_clear_thing('#thinglist-box>.list-box','thinglist-loading-box');
            loading_page = 1;
            page_items = -1;
            loading_start("#thinglist-loading-box");
            get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
                },
    });
  
	/* thingsearch页 */
	search_box_select = new MobileSelect({
        trigger: "#search-box-select",
        title: "选择分类",
        triggerDisplayData:false,
        wheels: [
            {data:[{id:'1',value:'请选择分类'},]},
        ],
        position: [0], //初始化定位 打开时默认选中的哪个 如果不填默认为0
        transitionEnd: function (indexArr, data) {//每一次改动产生的事件
            //console.log(data);
        },
        callback: function (indexArr, data) {
            $("#search-box-select>.text").text(data[0].value);
        },
    });
	get_class(user_id,"boxlist");
	
	//获取首页临期物品
	alert_thing_clear(1);
	alert_thing_clear(0);
	get_thing_alert(user_id,1,1);
	get_thing_alert(user_id,0,1);
	
	//待优化
	setTimeout(function() {alert_thing_ready(); }, 500); 
	
	
	/* 	main页 */
	time_cookie_exist("edit-email-get", "#edit-email-get", "#edit-email-get>span");
	time_cookie_exist("edit-phone-get", "#edit-phone-get", "#edit-phone-get>span");
	setTimeout(function() {$("#loading_page").fadeOut(300); }, 1000); 
	
}

//主要针对things数组，根据t_id获取id
function get_thing_id(t_id){
    i = things.findIndex(v=>v.t_id == t_id);
    return i;
}

//主要针对classes数组，根据c_id获取id
function get_class_id(c_id){
    i = classes.findIndex(v=>v.c_id == c_id);
    return i;
}

//主要针对classes数组，根据c_name获取id
function get_class_name(c_name){
    i = classes.findIndex(v=>v.value == c_name);
    return i;
}

//两个时间相差天数 兼容firefox chrome
function  getDaysBetween(dateString1,dateString2){
    var  startDate = Date.parse(dateString1);
    var  endDate = Date.parse(dateString2);
    if (startDate > endDate){
        var days = (startDate - endDate)/(1*24*60*60*1000);
        return -days;
    }
    if (startDate==endDate){
        return 0;
    }
    var days = (endDate - startDate)/(1*24*60*60*1000);
    return  days;
}

//计算某天后多少天的日期
function AddDays(date, num) {
    var startDate = Date.parse(date);
    var newtimems = startDate + (num * 24 * 60 * 60 * 1000);
    var newdate = new Date();
    newdate.setTime(newtimems);
    var time = newdate.getFullYear() + "-" + addchar((newdate.getMonth()+1).toString(),2,"0") + "-" + addchar(newdate.getDate().toString(),2,"0");
    return time;
}

//压入历史记录事件
function historypush(obj){
    close_obj_history.push(obj);
    window.history.pushState("","","");
};

//返回事件
function goback(id){
    $("#loading_page").fadeOut(300);
    switch (id) {
		//明天过期信息
        case 'tomorrow':
            if(tomorrow_tab == 1){
                tomorrow_tab = 0;
                $("#tomorrow").css("opacity","1");
                $('.magnify-box').fadeOut(300);
                $('#pannel-index>.pannel>.shade').fadeOut(300);
                close_obj_history.pop();
            }
            break;
			
		//今天过期信息
        case 'today':
            if(today_tab == 1){
                today_tab = 0;
                $("#today").css("opacity","1");
                $('.magnify-box').fadeOut(300);
                $('#pannel-index>.pannel>.shade').fadeOut(300);
                close_obj_history.pop();
            }
            break;
			
		//物品列表返回
        case '#thinglist-box>.head>.return-box':
            thinglist_open = 0;
            setTimeout(function(){ list_clear_thing('#thinglist-box>.list-box','thinglist-loading-box'); }, 300);
            $("#thinglist-box").css("transform","translateX(100%)");
            close_obj_history.pop();
            break;
			
		//物品列表条件返回
        case 'mobileselect':
            temp_close_obj.hide();
            if(typeof search_box_select_open !== "undefined"){
                if(search_box_select_open == 1){
                    search_box_select_open = 0;
                }
            }
            close_obj_history.pop();
            temp_close_obj = null;
            break;
			
		//添加物品返回
        case '#thingadd-box>.head>.return-box':
            $("#thingadd-box>.add-box").css("opacity","0");
            $("#thingadd-box").css("transform","translateX(100%)");
            //表示无打开细节
            thingadd_box_open = 0;
            thing_edit_open = 0;
            search_edit_open = 0;
            thing_detail_box_open_item = 0;
            close_obj_history.pop();
            break;
			
		//物品查询返回
        case '#thingsearch-box>.head>.return-box':
            searchlist_open = 0;
            $("#thingsearch-box").css("transform","translateX(100%)");
            close_obj_history.pop();
            break;
			
		//箱子添加返回
        case '#addclass-box>.head>.return-box':
            $("#addclass-box").css("transform","translateY(0%)");
            $('#pannel-boxlist>.shade').fadeOut();
            close_obj_history.pop();
            addclass_box_open = 0;
            editclass_box_open = 0;
            break;
			
		//物品批量删除返回
        case 'thinglist_batch_del_box':
            $("#thinglist-box>.bacth").css("transform","translateY(0%)");
            $("#thinglist-box>.list-box").css("height","calc(100% - 140px)");
            $("#thinglist-box>.list-box>.card-box>.card").css("margin-left","calc(50% - 150px)");
            $("#thinglist-box>.list-box>.card-box>.card").css("filter","grayscale(0)");
            $("#thinglist-box>.list-box>.card-box>.card").css("opacity","1");
            $("#thinglist-box>.list-box>.card-box>.batch-box").css("transform","translateX(-40px)");
            $("#thinglist-box>.list-box>.card-box>.batch-box").fadeOut(100);
            $("#thinglist-box>.list-box>.card-box>.card>.body>.btnbox").fadeIn(300);
            close_obj_history.pop();
            thinglist_batch_del_box_open = 0;
            delthings = [];
            var bh = $("#thinglist-box>.list-box").height();		//body_height
            var bt = $("#thinglist-box>.list-box").offset().top;	//body_top
            var lt = $("#thinglist-loading-box").offset().top;		//loading_top
            if(lt  <= bt + bh - 30){
                //响应事件
                if(page > 0 && loading_page == 0 && thinglist_batch_del_box_open == 0){
                    loading_page = 1;
                    get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
                }
            }
            break;
			
		//隐藏物品详情弹窗
        case 'thing_detail_box_open':
            $("#detail-box").fadeOut(100);
            $("#detail-shade").fadeOut(100);
            thing_detail_box_open = 0;
            close_obj_history.pop();
            break;
			
		//隐藏安全设置弹窗
        case '#mine-safe':
            $("#mine-safe").css("transform","translateX(100%)");
            mine_safe = 0;
            close_obj_history.pop();
            break;
			
		//隐藏帮助弹窗
        case '#mine-help':
            $("#mine-help").css("transform","translateX(100%)");
            mine_help = 0;
            close_obj_history.pop();
            break;
			
		//隐藏设置弹窗
        case '#mine-set':
            $("#mine-set").css("transform","translateX(100%)");
            mine_set = 0;
            close_obj_history.pop();
            break;
			
		//隐藏物品搜索条件盒子
        case '#search-item-box':
            $("#search-item-box").css("transform","translateX(100%)");
            $("#thingsearch-box>.shade").fadeOut(100);
            search_open = 0;
            close_obj_history.pop();
            break;
			
		//物品批量删除返回
        case 'search_batch_del_box':
            $("#search-box>.bacth").css("transform","translateY(0%)");
            $("#search-box>.list-box").css("height","calc(100% - 120px)");
            $("#search-box>.list-box>.card-box>.card").css("transform","translateX(0%)");
            $("#search-box>.list-box>.card-box>.card").css("filter","grayscale(0)");
            $("#search-box>.list-box>.card-box>.card").css("opacity","1");
            $("#search-box>.list-box>.card-box>.batch-box").fadeOut(300);
            $("#search-box>.list-box>.card-box>.batch-box").css("transform","translateX(-40px)");
            $("#search-box>.list-box>.card-box>.card>.body>.btnbox").fadeIn(300);
            $("#thingsearch-box>.head>.open-searchbox").show();
            close_obj_history.pop();
            search_batch_del_box_open = 0;
            delthings = [];
            var bh = $("#search-box>.list-box").height();			//body_height
            var bt = $("#search-box>.list-box").offset().top;		//body_top
            var lt = $("#searchlist-loading-box").offset().top;		//loading_top
            if(lt  <= bt + bh - 30){
                //响应事件
                if(page > 0  && loading_page == 0 && search_batch_del_box_open == 0){
                    loading_page = 1;
                    get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
                }
            }
            break;
			
		//隐藏修改头像窗
        case '#edit-avatar':
            open_edit_avatar = 0;
            $("#edit-avatar").fadeOut(300);
            $("#mine-safe>.shade").fadeOut(300);
            close_obj_history.pop();
            break;
			
		//隐藏修改昵称窗
        case '#edit-name':
            open_edit_name = 0;
            $("#edit-name").fadeOut(300);
            $("#mine-safe>.shade").fadeOut(300);
            close_obj_history.pop();
            break;
			
		//隐藏修改密码窗
        case '#edit-password':
            open_edit_password = 0;
            $("#edit-password").fadeOut(300);
            $("#mine-safe>.shade").fadeOut(300);
            close_obj_history.pop();
            break;
			
		//隐藏修改邮箱窗
        case '#edit-email':
            open_edit_email = 0;
            $("#edit-email").fadeOut(300);
            $("#mine-safe>.shade").fadeOut(300);
            close_obj_history.pop();
            break;
			
		//隐藏修改手机窗
        case '#edit-phone':
            open_edit_phone = 0;
            $("#edit-phone").fadeOut(300);
            $("#mine-safe>.shade").fadeOut(300);
            close_obj_history.pop();
            break;
			
		//隐藏细节窗
        case '#record-box>.head>.return-box':
            $("#record-box").css("transform","translateX(100%)");
            if(typeof thing_detail_record_open !== "undefined"){
                if(thing_detail_record_open == 1){
                    thing_detail_record_open = 0;
                }
            }
            thing_detail_box_open_item = 0;
            close_obj_history.pop();
            break;
        
        //隐藏修改询问窗
        case 'require_box':
            if(typeof require_box_open !== "undefined"){
                if(require_box_open == 1){
                    require_box_open = 0;
                    $('.require-shade').fadeOut(300);
                    $(".require-box").remove();
                    setTimeout(function(){ $('.require-shade').remove(); }, 300);
                }
            }
            close_obj_history.pop();
            break;
        case 'get_avatar':
            $("#clipic").css("transform","translate(0, 100%)");
            close_obj_history.pop();
            break;
        case 'soft_info':
            $("#mine-softinfo").css("transform","translateX(100%)");
            soft_info = 0;
            close_obj_history.pop();
            break;
        case 'aboutus':
            $("#mine-about").css("transform","translateX(100%)");
            aboutus = 0;
            close_obj_history.pop();
            break;
        default:
            // code
    }
}

//记录时间类型的cookie  name-cookie名 target_body-响应体目标名 target_text-相应文字目标名
function time_cookie_exist(name, target_body, target_text){
    if($.cookie(name)){				//存在cookie
        var time = $.cookie(name);	//获取cookie
        var time_now = Date.now();
        var differ = parseInt( (time - time_now) / 1e3 );	//获取相差的秒数
        $(target_body).addClass("disabled");				//目标设置禁用态
        if( differ >= 60){
            var min = parseInt(differ / 60);
            var sec = differ - min * 60;
            $(target_text).text(min + "分" + sec + "秒后重获");
            
        }
        else if( differ > 0){
            $(target_text).text(differ + "秒后重获");
        }
        else{
            $(target_body).removeClass("disabled");			//目标设置禁用态
            $(target_text).text("重新获取");
        }
        
        if(differ > 0){
            var resend = setInterval(
    	    function()
    	    {
    			differ --;
    			var timeout;
    			if( differ >= 60){
                    var min = parseInt(differ / 60);
                    var sec = differ - min * 60;
                    $(target_text).text(min + "分" + sec + "秒后重获");
                    timeout = Date.now() + differ * 1000;
    				$.cookie(name, timeout, {path: '/', expires: (1 / 86400) * differ});
                }
                else if( differ > 0){
                    $(target_text).text(differ + "秒后重获");
                    timeout = Date.now() + differ * 1000;
    				$.cookie(name, timeout, {path: '/', expires: (1 / 86400) * differ});
                }
                else{
                    $(target_body).removeClass("disabled");	//目标设置禁用态
                    $(target_text).text("重新获取");
                    clearInterval(resend);
                }
    		}, 1000);
        }  
    }
}

//切换页面用的
function getpageid(s){
    var res = "#pannel-" + s.slice(3);
    return res;
}

//实现顶部提醒然后自动过一段时间删除，添加提醒
function add_msg(msg, type = 1){
    msg_list ++;
    if(msg_list == 99999)msg_list = 1;
    var mid = "msg_list_" + msg_list;
    var icon;
    var color = "t" + type;
    switch(type){
        case 1:
            icon = "lq-zhengchang2";
            break;
        case 2:
            icon = "lq-jinggao7";
            break;
        case 3:
            icon="lq-shanchuyixuanqunchengyuanchacha";
            break;
        default:
            break;
    }
    
    var code = '<div class="card" id="' + mid + '">\
        <div class="type ' + color + '">\
            <span class="hymicon ' + icon + '"></span>\
        </div>\
        <div class="msg">\
            <span>' + msg + '</span>\
        </div>\
    </div>';
	
    $('#feedback-msg').prepend(code);
    var hide = setInterval(
        function()
        {
    		$("#" + mid).remove();
            clearInterval(hide);
    	}, 4100);
}

//addthing页设置初始的参数
function addthing_set(id){
    var cid = get_class_id(things[id].t_c_id);
    var ddldays = getDaysBetween(things[id].t_date,things[id].t_ddldate);
    var lqtime = AddDays(things[id].t_ddldate, -things[id].t_alert_day);
    var t = things[id].t_date.split("-");
    produce_date.locatePosition(0,t[0] - 1999);
    produce_date.locatePosition(1,t[1] - 1);
    produce_date.locatePosition(2,t[2] - 1);
    t = things[id].t_ddldate.split("-");
    overdue_date.locatePosition(0,t[0] - 1999);
    overdue_date.locatePosition(1,t[1] - 1);
    overdue_date.locatePosition(2,t[2] - 1);
    t = lqtime.split("-");
    near_date.locatePosition(0,t[0] - 1999);
    near_date.locatePosition(1,t[1] - 1);
    near_date.locatePosition(2,t[2] - 1);
    classselect.locatePosition(0,cid);
    var addthing_name = things[id].t_name;
    var addthing_num = things[id].t_num;
    var addthing_boxclass = classes[cid].value;
    var addthing_produce_date = things[id].t_date;
    var addthing_overdue_date = things[id].t_ddldate;
    var addthing_overdue_date_num = ddldays;
    var addthing_near_date = lqtime;
    var addthing_near_days = things[id].t_alert_day;
    var addthing_beizhu = things[id].t_remark;
    $("#addthing_name").val(addthing_name);
    $("#addthing_num").val(addthing_num);
    $("#addthing_boxclass").val(addthing_boxclass);
    $("#addthing_produce_date").val(addthing_produce_date);
    $("#addthing_overdue_date").val(addthing_overdue_date);
    $("#addthing_overdue_date_num").val(addthing_overdue_date_num);
    $("#addthing_near_date").val(addthing_near_date);
    $("#addthing_near_days").val(addthing_near_days);
    $("#addthing_beizhu").val(addthing_beizhu);
    $("#addthing_beizhu_len").text($("#addthing_beizhu").val().length + "/1000");
    setTimeout(function() {$("#loading_page").fadeOut(300); }, 300); 
};

//添加分类的盒子数据清空
function addclass_clear(){
    $("#sub_addclass").css("background-color","rgba(200,200,200,0.7)");
    $("#addclass_name").val("");
    $("#addclass_beizhu").val("");
}

//添加分类的盒子数据设置
function addclass_set(name,beizhu){
    $("#addclass_name").val(name);
    $("#addclass_beizhu").val(beizhu);
    $("#loading_page").fadeOut(200);
}

//添加分类列表添加
function addclass_add(c_id,c_name,c_beizhu,c_num){
    var code;
    if(c_name != "默认"){
        code ='\
        <div class="card" id="c_' + c_id + '">\
            <div class="iconbox">\
                <span class="hymicon lq-beizhu"></span>\
            </div>\
            <div class="tagname">\
                <span>' + c_name + '</span>\
            </div>\
            <div class="info-box">\
                <div class="num">\
                    <span>共</span>\
                    <span class="v">' + c_num + '</span>\
                    <span>个物品</span>\
                </div>\
                <div class="remark">\
                    <span>' + c_beizhu + '</span>\
                </div>\
            </div>\
            <div class="button">\
                <div class="del">\
                    <span class="hymicon lq-chahao"></span>\
                    <span>删除</span>\
                </div>\
                <div class="edit">\
                    <span class="hymicon lq-bianji"></span>\
                    <span>编辑</span>\
                </div>\
            </div>\
        </div>';
    }
    else{
        code ='\
        <div class="card" id="c_' + c_id + '">\
            <div class="iconbox">\
                <span class="hymicon lq-beizhu"></span>\
            </div>\
            <div class="tagname">\
                <span>' + c_name + '</span>\
            </div>\
            <div class="info-box">\
                <div class="num">\
                    <span>共</span>\
                    <span class="v">' + c_num + '</span>\
                    <span>个物品</span>\
                </div>\
                <div class="remark">\
                    <span>' + c_beizhu + '</span>\
                </div>\
            </div>\
        </div>';
    }
    $('#boxlist-loading-box').before(code);
}
//添加分类列表修改分类
function addclass_edit(c_id,c_name,c_beizhu,c_num){
    var code ='\
        <div class="iconbox">\
            <span class="hymicon lq-beizhu"></span>\
        </div>\
        <div class="tagname">\
            <span>' + c_name + '</span>\
        </div>\
        <div class="info-box">\
            <div class="num">\
                <span>共</span>\
                <span class="v">' + c_num + '</span>\
                <span>个物品</span>\
            </div>\
            <div class="remark">\
                <span>' + c_beizhu + '</span>\
            </div>\
        </div>\
        <div class="button">\
            <div class="del">\
                <span class="hymicon lq-chahao"></span>\
                <span>删除</span>\
            </div>\
            <div class="edit">\
                <span class="hymicon lq-bianji"></span>\
                <span>编辑</span>\
            </div>\
        </div>';
    $("#c_" + c_id).html(code);
}

//前导补0，常用日期格式化
function addchar(text,num,char){
    for(var i = 0;i<num - text.length;i++){
        text = char + text;
    }
    return text;
}

//生成日期选择
function dateoption(){
    years = [];
    months = [];
    days_28 = [];//28天数
    days_29 = [];//29天数
    days_30 = [];//30天数
    days_31 = [];//31天数
    for(var i = 1; i<=31; i++){
        var day = new Object();
        day.id = i.toString();
        day.value = addchar(i.toString(),2,'0');
        if(i <= 28){days_28.push(day);}
        if(i <= 29){days_29.push(day);}
        if(i <= 30){days_30.push(day);}
        if(i <= 31){days_31.push(day);}
    }
    
    for(var i = 1; i<=12; i++){
        var month = new Object();
        month.id = i.toString();
        month.value = addchar(i.toString(),2,'0');
        months.push(month);
    }
    
    for(var i = 1999; i<=2099;i++){
        var year = new Object();
        year.id = i.toString();
        year.value = i.toString();
        years.push(year);
    }
}

//生成日期选择
function dateoption2(){
    years_ = [];
    months_ = [];
    days_28_ = [];//28天数
    days_29_ = [];//29天数
    days_30_ = [];//30天数
    days_31_ = [];//31天数
    var day = new Object();
    day.id = "0";
    day.value = "不限";
    days_28_.push(day);
    days_29_.push(day);
    days_30_.push(day);
    days_31_.push(day);
    var month = new Object();
    month.id = "0";
    month.value = "不限";
    months_.push(month);
    var year = new Object();
    year.id = "0";
    year.value = "不限";
    years_.push(year);
    for(var i = 1; i<=31; i++){
        day = new Object();
        day.id = i.toString();
        day.value = addchar(i.toString(),2,'0');
        if(i <= 28){days_28_.push(day);}
        if(i <= 29){days_29_.push(day);}
        if(i <= 30){days_30_.push(day);}
        if(i <= 31){days_31_.push(day);}
    }
    
    for(var i = 1; i<=12; i++){
        month = new Object();
        month.id = i.toString();
        month.value = addchar(i.toString(),2,'0');
        months_.push(month);
    }
    
    for(var i = 1999; i<=2099;i++){
        year = new Object();
        year.id = i.toString();
        year.value = i.toString();
        years_.push(year);
    }
}

//添加物品  --id为数组小标编号，t_id是物品id，name为物品名，classname是类别名，days剩余事件，num剩余数量，creat_day创建日期，remark备注，type为safe或warn或danger
function list_add_thing(id,t_id,name,classname,days,num,creat_day,remark,type,bind){
    var card_id = id + "_" + t_id;
    var text_piece = "距离过期还有";
    if(type == "danger"){
        text_piece = "已过期";
    }
    var add_code = 
    '<div class="card-box" id="t_' + card_id + '">\
        <div class="card">\
            <div class="head ' + type + '">\
                <div class="classname">\
                    <span class="hymicon lq-beizhu"></span>\
                    <span>' + classname + '</span>\
                </div>\
                <div class="days">\
                    <span class="s">天</span>\
                    <span>' + days + '</span>\
                    <span class="s">' + text_piece +'</span>\
                </div>\
            </div>\
            <div class="body">\
                <div class="info">\
                    <div class="topbox">\
                        <div class="name">\
                            ' + name + '\
                        </div>\
                        <div class="num">\
                            <span>剩余:</span>\
                            <span class="v">' + num + '</span>\
                        </div>\
                    </div>\
                    <div class="bottombox">\
                        <div class="time">\
                            ' + creat_day + '\
                        </div>\
                        <div class="break"></div>\
                        <div class="remark">\
                            ' + remark + '\
                        </div>\
                    </div>\
                </div>\
                <div class="btnbox">\
                    <div class="btn edit">\
                        <span class="hymicon lq-beizhu- edit">编辑</span>\
                    </div>\
                    <div class="btn del">\
                        <span id="del_t_' + card_id + '" class="hymicon lq-quancha del">删除</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div class="batch-box">\
            <input type="checkbox" />\
        </div>\
    </div>\
    ';
    $(bind).before(add_code);
}

//物品列表清空
function list_clear_thing(bind, id){
    things = [];
    var code = '\
        <div id="' + id + '" class="loading-boxes">\
            <div class="icon">\
                <span class="hymicon lq-loading"></span>\
            </div>\
            <div class="text">\
                <span>正在加载中··</span>\
            </div>\
        </div>';
    $(bind).html(code);
}

//加载开始
function loading_start(bind){
    var code = '<div class="icon">\
                <span class="hymicon lq-loading"></span>\
            </div>\
            <div class="text">\
                <span>正在加载中··</span>\
            </div>';
    $(bind).html(code);
}

//加载结束
function loading_end(bind){
    $(bind).html(stoploadingcode);
}

//物品列表物品删除
function list_remove_thing(id,type){
    $(id).remove();
}
;

//添加物品页清空
function addthing_clear(){
    $("#addthing_name").val("");
    $("#addthing_num").val("");
    $("#addthing_boxclass").val("");
    $("#addthing_produce_date").val("");
    $("#addthing_overdue_date").val("");
    $("#addthing_overdue_date_num").val("");
    $("#addthing_near_date").val("");
    $("#addthing_near_days").val("");
    $("#addthing_beizhu").val("");
    overdue_date.locatePosition(0,year_now - 1999);
    overdue_date.locatePosition(1,month_now);
    overdue_date.locatePosition(2,day_now - 1);
    near_date.locatePosition(0,year_now - 1999);
    near_date.locatePosition(1,month_now);
    near_date.locatePosition(2,day_now - 1);
    produce_date.locatePosition(0,year_now - 1999);
    produce_date.locatePosition(1,month_now);
    produce_date.locatePosition(2,day_now - 1);
    $("#loading_page").fadeOut(300);
}

//开始询问
function add_require(title, text, bt1, bt2, bt1id, bt2id, bind){
    if(require_box_open == 0){
        var id1="";
        var id2="";
        if(bt1id != ""){
            bt1id = 'id="' + bt1id + '"';
        }
        if(bt2id != ""){
            bt2id = 'id="' + bt2id + '"';
        }
        var code = '<div class="require-shade"></div>\
            <div class="require-box">\
                <div class="head-box">\
                    <div class="title">\
                        <span>' + title + '</span>\
                    </div>\
                    <div class="cancel">\
                        <span class="hymicon lq-chacha2"></span>\
                    </div>\
                </div>\
                <div class="text-box">\
                    ' + text + '\
                </div>\
                <div class="btn-box">\
                    <div class="btn sure" ' + bt1id + '>\
                        <span>' + bt1 + '</span>\
                    </div>\
                    <div class="btn cancel" ' + bt2id + '>\
                        <span>' + bt2 + '</span>\
                    </div>\
                </div>\
            </div>';
        $(bind).append(code);
        historypush("require_box");
        require_box_open = 1;
    }
}

//删除分类class处理
function delclasses(c_id){
    var id = get_class_id(c_id);
    var id_index = get_class_id(class_index);
    classes[id_index].num = classes[id_index].num  + classes[id].num;
    $("#c_" + class_index + ">.info-box>.num>.v").text(classes[id_index].num);
    classes.splice( id ,1);
}

function htmlEncodeJQ ( str ) {
    return $('<span/>').text( str ).html();
}
 
function htmlDecodeJQ ( str ) {
    return $('<span/>').html( str ).text();
}

function thing_edit_card(t_name,n_id,card_id,name,classname,days,num,creat_day,remark,type){
    var text_piece = "距离过期还有";
    if(type == "danger"){
        text_piece = "已过期";
    }
    $("#detail-box-thingname").text(t_name);
    var code = '<div class="card">\
            <div class="head ' + type + '">\
                <div class="classname">\
                    <span class="hymicon lq-beizhu"></span>\
                    <span>' + classname + '</span>\
                </div>\
                <div class="days">\
                    <span class="s">天</span>\
                    <span>' + days + '</span>\
                    <span class="s">' + text_piece +'</span>\
                </div>\
            </div>\
            <div class="body">\
                <div class="info">\
                    <div class="topbox">\
                        <div class="name">\
                            ' + name + '\
                        </div>\
                        <div class="num">\
                            <span>剩余:</span>\
                            <span>' + num + '</span>\
                        </div>\
                    </div>\
                    <div class="bottombox">\
                        <div class="time">\
                            ' + creat_day + '\
                        </div>\
                        <div class="break"></div>\
                        <div class="remark">\
                            ' + remark + '\
                        </div>\
                    </div>\
                </div>\
                <div class="btnbox">\
                    <div class="btn edit">\
                        <span class="hymicon lq-beizhu- edit">编辑</span>\
                    </div>\
                    <div class="btn del">\
                        <span id="del_t_' + card_id + '" class="hymicon lq-quancha del">删除</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div class="batch-box">\
            <input type="checkbox" />\
        </div>';
    $(n_id).html(code);
}

function set_detail_card(id){
    var creat_time = things[id].t_createdate;
    var type = "";
    var ddl_day = getDaysBetween(y_m_d_now,things[id].t_ddldate);
    $("#detail-box>.head").removeClass('safe');
    $("#detail-box>.head").removeClass('danger');
    $("#detail-box>.head").removeClass('warn');
    if(ddl_day > things[id].t_alert_day){
        type = "safe";
    }
    else if(ddl_day >= 0){
        type = "warn";
    }
    else{
        type = "danger";
    }
    $("#detail-box>.head").removeClass('info').addClass(type);
    var text_piece = "距离过期还有";
    if(type == "danger"){
        text_piece = "已过期";
    }
    $("#detail-box").attr("name",id);
    ddl_day = Math.abs(ddl_day);
    var pro_day = things[id].t_date;
    var num = things[id].t_num;
    var beizhu = things[id].t_remark;
    var cid = get_class_id(things[id].t_c_id);
    var classname = classes[cid].value;
    var thingname = things[id].t_name;
    
    $("#detail-box-thingname").text(thingname);
    $("#detail-box-classname").text(classname);
    $("#detail-box-ddlday").text(ddl_day);
    $("#detail-box-type").text(text_piece);
    $("#detail-box-create").text(creat_time);
    $("#detail-box-produce").text(pro_day);
    $("#detail-box-num").text(num);
    $("#detail-box-beizhu").text(beizhu);
    $("#loading_page").fadeOut(300);
}

//首页弹出卡片加载
function load_alert_thing(type){
    if(type == 1){
        $("#biggerlist>.title-box>.title>.name").text("今日过期");
    }
    else{
        $("#biggerlist>.title-box>.title>.name").text("明日过期");
    }
    $("#biggerlist>.list").html("");
    var name,t_id,num,classname,creatdate;
    var code = "";
    if(type == 1){
        for(var i = 0; i < thingtodays.length; i++){
            name = thingtodays[i].t_name;
            var c_id = thingtodays[i].t_c_id;
            classname = classes[get_class_id(c_id)].value;
            num = thingtodays[i].t_num;
            t_id = thingtodays[i].t_id;
            creatdate = thingtodays[i].t_createdate;
            /*code = code + '\
                <div class="card" id="bc_'+ t_id +'">\
                    <div class="box">\
                        <div class="icon">\
                            <span class="hymicon lq-beizhu"></span>\
                        </div>\
                        <div class="text">\
                            <span>' + classname + '</span>\
                        </div>\
                    </div>\
                    <div class="name">\
                        <span>' + name + '</span>\
                    </div>\
                    <div class="info">\
                        <div class="num">\
                            <span>剩余:' + num + '</span>\
                        </div>\
                        <div class="time">\
                            <span>创建于:' + creatdate + '</span>\
                        </div>\
                    </div>\
                    <div class="btn">\
                        <span class="hymicon lq-anniu-jiantouxiangyou"></span>\
                    </div>\
                </div>';*/
            code = code + '\
                <div class="card" id="bc_'+ t_id +'">\
                    <div class="box">\
                        <div class="icon">\
                            <span class="hymicon lq-beizhu"></span>\
                        </div>\
                        <div class="text">\
                            <span>' + classname + '</span>\
                        </div>\
                    </div>\
                    <div class="name">\
                        <span>' + name + '</span>\
                    </div>\
                    <div class="info">\
                        <div class="num">\
                            <span>剩余:' + num + '</span>\
                        </div>\
                        <div class="time">\
                            <span>创建于:' + creatdate + '</span>\
                        </div>\
                    </div>\
                </div>';
        }
        
    }
    else{
        for(var i = 0; i < thingtomorrows.length; i++){
            name = thingtomorrows[i].t_name;
            var c_id = thingtomorrows[i].t_c_id;
            classname = classes[get_class_id(c_id)].value;
            num = thingtomorrows[i].t_num;
            t_id = thingtomorrows[i].t_id;
            creatdate = thingtomorrows[i].t_createdate;
            /*code = code + '\
                <div class="card" id="bc_'+ t_id +'">\
                    <div class="box">\
                        <div class="icon">\
                            <span class="hymicon lq-beizhu"></span>\
                        </div>\
                        <div class="text">\
                            <span>' + classname + '</span>\
                        </div>\
                    </div>\
                    <div class="name">\
                        <span>' + name + '</span>\
                    </div>\
                    <div class="info">\
                        <div class="num">\
                            <span>剩余:' + num + '</span>\
                        </div>\
                        <div class="time">\
                            <span>创建于:' + creatdate + '</span>\
                        </div>\
                    </div>\
                    <div class="btn">\
                        <span class="hymicon lq-anniu-jiantouxiangyou"></span>\
                    </div>\
                </div>';*/
            code = code + '\
                <div class="card" id="bc_'+ t_id +'">\
                    <div class="box">\
                        <div class="icon">\
                            <span class="hymicon lq-beizhu"></span>\
                        </div>\
                        <div class="text">\
                            <span>' + classname + '</span>\
                        </div>\
                    </div>\
                    <div class="name">\
                        <span>' + name + '</span>\
                    </div>\
                    <div class="info">\
                        <div class="num">\
                            <span>剩余:' + num + '</span>\
                        </div>\
                        <div class="time">\
                            <span>创建于:' + creatdate + '</span>\
                        </div>\
                    </div>\
                </div>';
        }
    }
    $("#biggerlist>.list").html(code);
}

//首页卡片初始化
function alert_thing_ready(){
    var id;
    var name;
    var classname;
    var num;
    var creatdate;
    var type_ = "";
    var t_id;
    var code = "";
    for(var i = 0; i < thingtodays.length; i++){
        t_id = thingtodays[i].t_id;
        id = get_alertthing_id(1, t_id);
        type_ = "td_" + t_id.toString();
        name = thingtodays[id].t_name;
        var c_id = thingtodays[id].t_c_id;
        classname = classes[get_class_id(c_id)].value;
        num = thingtodays[id].t_num;
        creatdate = thingtodays[id].t_createdate;
        /*code = '\
        <div class="swiper-slide card" name="' + type_ + '">\
            <div class="name">\
                <div>'+ name +'</div>\
            </div>\
            <div class="box">\
                <p>类别:</p>\
                <span>' + classname + '</span>\
            </div>\
            <div class="num">\
                <p>剩余数量:</p>\
                <span>' + num + '</span>\
            </div>\
            <div class="date">\
                <p>创建日期:</p>\
                <span>' + creatdate + '</span>\
            </div>\
            <div class="btn">\
                <span>立即查看</span>\
            </div>\
        </div>';*/
        code = '\
        <div class="swiper-slide card" name="' + type_ + '">\
            <div class="name">\
                <div>'+ name +'</div>\
            </div>\
            <div class="box">\
                <p>类别:</p>\
                <span>' + classname + '</span>\
            </div>\
            <div class="num">\
                <p>剩余数量:</p>\
                <span>' + num + '</span>\
            </div>\
            <div class="date">\
                <p>创建日期:</p>\
                <span>' + creatdate + '</span>\
            </div>\
        </div>';
        $("#todaycard>.swiper-wrapper").append(code);
    }
    for(var i = 0; i < thingtomorrows.length; i++){
        t_id = thingtomorrows[i].t_id;
        id = get_alertthing_id(0, t_id);
        type_ = "tm_" + t_id.toString();
        name = thingtomorrows[id].t_name;
        var c_id = thingtomorrows[id].t_c_id;
        classname = classes[get_class_id(c_id)].value;
        num = thingtomorrows[id].t_num;
        creatdate = thingtomorrows[id].t_createdate;
        /*code = '\
        <div class="swiper-slide card" name="' + type_ + '">\
            <div class="name">\
                <div>'+ name +'</div>\
            </div>\
            <div class="box">\
                <p>类别:</p>\
                <span>' + classname + '</span>\
            </div>\
            <div class="num">\
                <p>剩余数量:</p>\
                <span>' + num + '</span>\
            </div>\
            <div class="date">\
                <p>创建日期:</p>\
                <span>' + creatdate + '</span>\
            </div>\
            <div class="btn">\
                <span>立即查看</span>\
            </div>\
        </div>';*/
        code = '\
        <div class="swiper-slide card" name="' + type_ + '">\
            <div class="name">\
                <div>'+ name +'</div>\
            </div>\
            <div class="box">\
                <p>类别:</p>\
                <span>' + classname + '</span>\
            </div>\
            <div class="num">\
                <p>剩余数量:</p>\
                <span>' + num + '</span>\
            </div>\
            <div class="date">\
                <p>创建日期:</p>\
                <span>' + creatdate + '</span>\
            </div>\
        </div>';
        $("#tomorrowcard>.swiper-wrapper").append(code);
    }
    if(thingtodays.length > 0){
        todayswiper = new Swiper("#todaycard", {
            // grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:false,//修改swiper的父元素时，自动初始化swiper
            initialSlide :0,
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                todayswiper.startAutoplay();
            　　todayswiper.reLoop(); 
            }
        });
    }
    if(thingtomorrows.length > 0){
        tomorrowswiper = new Swiper("#tomorrowcard", {
            grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:true,//修改swiper的父元素时，自动初始化swiper
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                tomorrowswiper.startAutoplay();
            　　tomorrowswiper.reLoop(); 
            },
        });
    }
}

//首页卡片清空
function alert_thing_clear(type){
    if(type == 1){
        $("#todaycard>.swiper-wrapper").html("");
    }
    else{
        $("#tomorrowcard>.swiper-wrapper").html("");
    }
}

//首页卡片添加
function alert_thing_add(type,t_id){
    var id = get_alertthing_id(type, t_id);
    var name;
    var classname;
    var num;
    var creatdate;
    var type_ = "";
    if(type == 1){
        type_ = "td_" + t_id.toString();
        name = thingtodays[id].t_name;
        var c_id = thingtodays[id].t_c_id;
        classname = classes[get_class_id(c_id)].value;
        num = thingtodays[id].t_num;
        creatdate = thingtodays[id].t_createdate;
    }
    else{
        type_ = "tm_" + t_id.toString();
        name = thingtomorrows[id].t_name;
        var c_id = thingtomorrows[id].t_c_id;
        classname = classes[get_class_id(c_id)].value;
        num = thingtomorrows[id].t_num;
        creatdate = thingtomorrows[id].t_createdate;
    }
    /*var code = '\
        <div class="swiper-slide card" name="' + type_ + '">\
            <div class="name">\
                <div>'+ name +'</div>\
            </div>\
            <div class="box">\
                <p>类别:</p>\
                <span>' + classname + '</span>\
            </div>\
            <div class="num">\
                <p>剩余数量:</p>\
                <span>' + num + '</span>\
            </div>\
            <div class="date">\
                <p>创建日期:</p>\
                <span>' + creatdate + '</span>\
            </div>\
            <div class="btn">\
                <span>立即查看</span>\
            </div>\
        </div>';*/
    var code = '\
        <div class="swiper-slide card" name="' + type_ + '">\
            <div class="name">\
                <div>'+ name +'</div>\
            </div>\
            <div class="box">\
                <p>类别:</p>\
                <span>' + classname + '</span>\
            </div>\
            <div class="num">\
                <p>剩余数量:</p>\
                <span>' + num + '</span>\
            </div>\
            <div class="date">\
                <p>创建日期:</p>\
                <span>' + creatdate + '</span>\
            </div>\
        </div>';
    if(type == 1){
        $("#todaycard>.swiper-wrapper").append(code);
        todayswiper = new Swiper("#todaycard", {
            // grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:false,//修改swiper的父元素时，自动初始化swiper
            initialSlide :0,
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                todayswiper.startAutoplay();
            　　todayswiper.reLoop(); 
            }
        });
    }
    else{
        $("#tomorrowcard>.swiper-wrapper").append(code);
        tomorrowswiper = new Swiper("#tomorrowcard", {
            grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:true,//修改swiper的父元素时，自动初始化swiper
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                tomorrowswiper.startAutoplay();
            　　tomorrowswiper.reLoop(); 
            },
        });
    }
    
}

//首页卡片删除
function alert_thing_del(type,t_id){
    var type_ = "";
    if(type == 1){
        var id = get_alertthing_id(1,t_id);
        if( id == -1)return 0;
        thingtodays.splice(id,1);
        type_ = "td_" + t_id.toString();
    }
    else{
        var id = get_alertthing_id(0,t_id);
        if( id == -1)return 0;
        thingtomorrows.splice(id,1);
        type_ = "tm_" + t_id.toString();
    }
    
    $('.swiper-slide').each(function () {
        if($(this).attr("name") == type_){
            $(this).remove();
        }
    });
    
    if(type == 1){
        todayswiper = new Swiper("#todaycard", {
            // grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:false,//修改swiper的父元素时，自动初始化swiper
            initialSlide :0,
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                todayswiper.startAutoplay();
            　　todayswiper.reLoop(); 
            }
        });
    }
    else{
        tomorrowswiper = new Swiper("#tomorrowcard", {
            grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:true,//修改swiper的父元素时，自动初始化swiper
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                tomorrowswiper.startAutoplay();
            　　tomorrowswiper.reLoop(); 
            },
        });
    }
}

//首页卡片更改
function alert_thing_edit(type,t_id){
    var id = get_alertthing_id(type, t_id);
    var name;
    var classname;
    var num;
    var creatdate;
    var type_ = "";
    if(type == 1){
        type_ = "td_" + t_id.toString();
        name = thingtodays[id].t_name;
        var c_id = thingtodays[id].t_c_id;
        classname = classes[get_class_id(c_id)].value;
        num = thingtodays[id].t_num;
        creatdate = thingtodays[id].t_createdate;
    }
    else{
        type_ = "tm_" + t_id.toString();
        name = thingtomorrows[id].t_name;
        var c_id = thingtomorrows[id].t_c_id;
        classname = classes[get_class_id(c_id)].value;
        num = thingtomorrows[id].t_num;
        creatdate = thingtomorrows[id].t_createdate;
    }
    /*var code='<div class="name">\
            <div>'+ name +'</div>\
        </div>\
        <div class="box">\
            <p>类别:</p>\
            <span>' + classname + '</span>\
        </div>\
        <div class="num">\
            <p>剩余数量:</p>\
            <span>' + num + '</span>\
        </div>\
        <div class="date">\
            <p>创建日期:</p>\
            <span>' + creatdate + '</span>\
        </div>\
        <div class="btn">\
            <span>立即查看</span>\
        </div>';*/
    var code='<div class="name">\
            <div>'+ name +'</div>\
        </div>\
        <div class="box">\
            <p>类别:</p>\
            <span>' + classname + '</span>\
        </div>\
        <div class="num">\
            <p>剩余数量:</p>\
            <span>' + num + '</span>\
        </div>\
        <div class="date">\
            <p>创建日期:</p>\
            <span>' + creatdate + '</span>\
        </div>';  
    $('.swiper-slide').each(function () {
        if($(this).attr("name") == type_){
            $(this).html(code);
        }
    });
    
    if(type == 1){
        todayswiper = new Swiper("#todaycard", {
            // grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:false,//修改swiper的父元素时，自动初始化swiper
            initialSlide :0,
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                todayswiper.startAutoplay();
            　　todayswiper.reLoop(); 
            }
        });
    }
    else{
        tomorrowswiper = new Swiper("#tomorrowcard", {
            grabCursor: true,
            effect: "creative",
            loop: true,
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
                reverseDirection: false,
                pauseOnMouseEnter:true,
            },
            observer:true,//修改swiper自己或子元素时，自动初始化swiper
            observeParents:true,//修改swiper的父元素时，自动初始化swiper
            creativeEffect: {
                prev: {
                    shadow: true,
                    translate: ["-120%", 0, -500],
                },
                next: {
                    shadow: true,
                    translate: ["120%", 0, -500],
                },
            },
            onSlideChangeEnd: function(swiper){
            　　swiper.update(); 
                tomorrowswiper.startAutoplay();
            　　tomorrowswiper.reLoop(); 
            },
        });
    }
}

//卡片id
function get_alertthing_id(type,t_id){
    if(type == 1){
        i = thingtodays.findIndex(v=>v.t_id == t_id);
        return i;
    }
    else{
        i = thingtomorrows.findIndex(v=>v.t_id == t_id);
        return i;
    }
}

//记录表的过程
function thing_record_clear(){
    $("#record_thing_name").text("");
    $("#record-box>.list-box").html("");
    $("#record_num").text("0");
}
function thing_record_num(num){
    $("#record_num").text(num);
}
function thing_record_name(name){
    if(name.length > 15){
        name = name.substring(0,13) + "...";
    }
    $("#record_thing_name").text(name);
}
function thing_record_add(l_date,l_time,l_text){
    var code = '<div class="card">\
            <div class="time">\
                <div class="dot">\
                    <span>●</span>\
                </div>\
                <span>' + l_date + '</span>\
                <span>' + l_time + '</span>\
            </div>\
            <div class="text">\
                <div class="line">\
                    <div></div>\
                </div>\
                <div class="detail">\
                    <p>' + l_text + '</p>\
                </div>\
            </div>\
        </div>';
    $("#record-box>.list-box").append(code);
}

//用户的初始化设置
function users_set(type){
    switch(type){
        case "all":
            $("#user_info_avatar").attr("src",user_info.u_avatar);
            $("#user_info_name").text(user_info.u_name);
            $("#user_info_id").text(user_info.u_id);
            $("#user_info_avatar_menu").attr("src",user_info.u_avatar);
            if(user_info.u_email){
                $("#user_info_email").text(user_info.u_email);
            }
            else{
                $("#user_info_email").text("未绑定");
            }
            if(user_info.u_phone){
                $("#user_info_phone").text(user_info.u_phone);
            }
            else{
                $("#user_info_phone").text("未绑定");
            }
            if(user_info.u_alert_inner == "1"){
                $("#user_info_alert_inner").addClass("active");
                $("#alert_info").css("display","flow-root");
            }
            else{
                $("#user_info_alert_inner").removeClass("active");
            }
            if(user_info.u_alert_phone == "1"){
                $("#user_info_alert_phone").addClass("active");
            }
            else{
                $("#user_info_alert_phone").removeClass("active");
            }
            if(user_info.u_alert_email == "1"){
                $("#user_info_alert_email").addClass("active");
            }
            else{
                $("#user_info_alert_email").removeClass("active");
            }
            break;
        case "name":
            $("#user_info_name").text(user_info.u_name);
            break;
        case "email":
            $("#user_info_email").text(user_info.u_email);
            break;
        case "phone":
            $("#user_info_phone").text(user_info.u_phone);
            break;
        case "avatar":
            $("#user_info_avatar").attr("src",user_info.u_avatar);
            $("#user_info_avatar_menu").attr("src",user_info.u_avatar);
            break;
        case "inner_thing":
            if (user_info.u_alert_inner == "1") {
                $("#alert_info").css("display","flow-root");
            }
            else{
                $("#alert_info").css("display","none");
            }
            break;
    }
}