var js = document.scripts;
var jsPath;
for(var i = js.length;i>0;i--){
 if(js[i-1].src.indexOf("haoyemao-ecode.js")>-1){
   jsPath = js[i-1].src.substring(0,js[i-1].src.lastIndexOf("/")+1);
 }
}
// 引用其他js文件
document.write('<script src="' + jsPath + 'md5.js" type="text/javascript"></script>');
document.write('<script src="' + jsPath + 'jquery.js" type="text/javascript"></script>');
class haoyemao_ecode{
    constructor(){
        this.code = "";
        this.msg = 0;
    }
    create(email){
        var resback = $.ajax({
            type:"POST",    //提交的方法
            async:false,
            url:jsPath + "get_ecode.php",    //提交的地址
            data:
            {
                'to':email,
            },//    序列化表单值
            dataType:'json',
            timeout:4000,
            success:function(data)
            {
                // var msg = data.msg;
                // switch(msg)
                // {
                //     case 0:
                //         alert("发送失败");
                //         break;
                //     case 1:
                //         alert('发送成功');
                //         break;
                //     case -1:
                //         alert("邮箱不正确");
                //         break;
                //     case -2:
                //         alert("签名不正确");
                //         break;
                //     case -100:
                //         alert("接口剩余调用次数不足！");
                //         break;
                //     default:
                //         alert("未知的异常");
                //         break;
                //         }
                        return data;//获取验证码的md5值
            },
            error:function(data)
            {
                alert("邮箱验证码接口错误");
            }
        });
        var res = JSON.parse(resback.responseText);
        this.code = res.code;
        this.msg = res.msg;
    }
    getcode(){
        return this.code;
    }
    getmsg(){
        return this.msg;
    }
}