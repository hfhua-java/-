<html>
<head>
    <meta charset="utf-8">
    <script type="text/javascript" src="./haoyemao-api.js"></script>
    <title>好耶猫API</title>
    <style>
        #p-code
        {
            height:40px;
            line-height:38px;
            max-width:100%;
            margin-left:5%;
            background-color:rgba(191, 120, 58,0.3);
            border-radius:7px;
            color:#fff;
            border-color:rgba(167, 56, 54,1);
            border-style:solid;
            box-sizing:border-box;
            border-width:2px;
            font-size:12px;
            outline:none;
            text-align:center;
        }
    </style>
</head>
<body>
    <div class="form-item">
        <div style="float:left;height:40px;width:30%;">
            <div id="p-code">获取验证码</div>
        </div>
    </div>
    <script>
    //手机验证码发送
    $(function(){
        $('#p-code').click(function()
        {
            var phonenumber = "*******6933";
            haoyemao_pcodes = new haoyemao_pcode();
            haoyemao_pcodes.create(phonenumber);
            
            alert(haoyemao_pcodes.getcode());//获取验证码的md5
            alert(haoyemao_pcodes.getmsg());//获取验证码错误信息
        });
    });
    </script>
</body>
</html>