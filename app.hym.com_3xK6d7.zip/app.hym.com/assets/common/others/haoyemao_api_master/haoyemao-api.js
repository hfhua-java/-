// 获取文件路径
var js = document.scripts;
var jsPath;
for(var i = js.length;i>0;i--){
 if(js[i-1].src.indexOf("haoyemao-api.js")>-1){
   jsPath = js[i-1].src.substring(0,js[i-1].src.lastIndexOf("/")+1);
 }
}
// 引用其他js文件
document.write('<script src="' + jsPath + 'md5.js" type="text/javascript"></script>');
document.write('<script src="' + jsPath + 'jquery.js" type="text/javascript"></script>');
function haoyemao_create_code()
{
    var taget=document.getElementsByClassName("haoyemao_code_box");
    var i;
    haoyemao_codes = new Array();
    fresh = new Array();
    for (i = 0; i < taget.length; i++) {
        haoyemao_codes[i] = new haoyemao_code(i);
        fresh.push(i);//队列依次处理
    }
    i = 0;
    haoyemao_codes[fresh[0]].reset(fresh);
    hym_error_repeat = 3;
}
class haoyemao_code
{
    constructor(index){
        this.index = index;
    }
    reset(fresh)
    {
        $.ajax({
            type: "POST", //提交的方法
            async: true, //异步
            url:jsPath + "get_api.php", //提交的地址
            data:
            {
                'index':this.index,
                'func':"code",
            },// 序列化表单值
            dataType:'json',
            timeout: 4000,
            success:function(data)
            {
                if(data.error == 1){
                    //layer.msg("签名验证失败", {icon: 2,time:1000,shade:0.4});
                }
                else if(data.error == -100){
                    //layer.msg("接口剩余调用次数不足！", {icon: 2,time:1000,shade:0.4});
                }
                else
                {
                    document.getElementsByClassName("haoyemao_code_box")[data.index].innerHTML='<img class="haoyemao_code_img" src="data:image/png;base64,'+ (data.img).replace(/\\\//g, '/') +'"/>\
                    <input class="haoyemao_code_data" style="display:none;" value="'+ md5(data.code) +'"/>\
                    ';
                    //防止拥堵。
                    fresh.shift();
                    if(fresh.length)
                    {
                        haoyemao_codes[fresh[0]].reset(fresh);
                    }
                }
            },
            error:function(data)
            {
                //layer.msg("验证码接口错误！", {icon: 2,time:1000,shade:0.4});
            }
        });
    }
    //验证是否正确，正确返回1
    check(input){
        var getdata = document.getElementsByClassName("haoyemao_code_data")[this.index].value;
        if(md5(input.toLowerCase()) == getdata)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}

class haoyemao_ecode{
    constructor(){
        this.code = "";
        this.msg = 0;
    }
    create(email){
        var resback = $.ajax({
            type:"POST",    //提交的方法
            async:false,
            url:jsPath + "get_api.php",    //提交的地址
            data:
            {
                'to':email,
                'func':"ecode",
            },//    序列化表单值
            dataType:'json',
            timeout:4000,
            success:function(data)
            {
                var msg = data.msg;
                switch(msg)
                {
                    case 0:
                        //layer.msg("发送失败");
                        break;
                    case 1:
                        //layer.msg('发送成功');
                        break;
                    case -1:
                        //layer.msg("邮箱不正确");
                        break;
                    case -2:
                        //layer.msg("签名不正确");
                        break;
                    case -100:
                        //layer.msg("接口剩余调用次数不足！");
                        break;
                    default:
                        //layer.msg("未知的异常");
                        break;
                    }
                        return data;//获取验证码的md5值
            },
            error:function(data)
            {
                //layer.msg("邮箱验证码接口错误");
            }
        });
        var res = JSON.parse(resback.responseText);
        this.code = res.code;
        this.msg = res.msg;
    }
    getcode(){
        return this.code;
    }
    getmsg(){
        return this.msg;
    }
}

class haoyemao_email{
    constructor(){
        this.to = "";
        this.msg = 0;
    }
    create(email,title,name,msg){
        msg.replace(/&/g, '&').replace(/\"/g, '"').replace(/</g, '<').replace(/>/g, '>');
        var resback = $.ajax({
            type:"POST",    //提交的方法
            async:false,
            url:jsPath + "get_api.php",    //提交的地址
            data:
            {
                'to':email,
                'title':title,
                'name':name,
                'v':msg,
                'func':"email",
            },//    序列化表单值
            dataType:'json',
            timeout:4000,
            success:function(data)
            {
                var msg = data.msg;
                switch(msg)
                {
                    case 0:
                        //layer.msg("发送失败", {icon: 2,time:1000,shade:0.4});
                        break;
                    case 1:
                        //layer.msg('发送成功', {icon: 1,time:1000,shade:0.4});
                        break;
                    case -1:
                        //layer.msg("邮箱不正确", {icon: 2,time:1000,shade:0.4});
                        break;
                    case -2:
                        //layer.msg("签名不正确", {icon: 2,time:1000,shade:0.4});
                        break;
                    case -100:
                        //layer.msg("接口剩余调用次数不足！", {icon: 2,time:1000,shade:0.4});
                        break;
                    default:
                        //layer.msg("未知的异常", {icon: 2,time:1000,shade:0.4});
                        break;
                        }
                        return data;
            },
            error:function(data)
            {
                //layer.msg("邮箱验证码接口错误", {icon: 2,time:1000,shade:0.4});
            }
        });
        var res = JSON.parse(resback.responseText);
        this.to = res.to;
        this.msg = res.msg;
    }
    getto(){
        return this.to;
    }
    getmsg(){
        return this.msg;
    }
}

class haoyemao_pcode{
    constructor(){
        this.code = "";
        this.msg = 0;
    }
    create(phonenumber){
        var resback = $.ajax({
            type:"POST",    //提交的方法
            async:false,    //异步
            url:jsPath + "get_api.php",    //提交的地址
            data:
            {
                'to':phonenumber,
                'func':"pcode",
            },//    序列化表单值
            dataType:'json',
            timeout:4000,
            success:function(data)
            {
                var msg = data.msg;
                switch(msg)
                {
                    case 0:
                        //layer.msg("发送失败");
                        break;
                    case 1:
                        //layer.msg('发送成功',{icon:1,time:1000,shade:0.4});
                        break;
                    case -1:
                        //layer.msg("手机号码不正确");
                        break;
                    case -2:
                        //layer.msg("签名不正确");
                        break;
                    case -3:
                        //layer.msg("发送上限");
                        break;
                    case -100:
                        //layer.msg("接口剩余调用次数不足！");
                        break;
                    default:
                        //layer.msg("未知的异常");
                        break;
                    }
            },
            error:function(data)
            {
                //layer.msg("手机验证码接口错误");
            }
        });
        var res = JSON.parse(resback.responseText);
        this.code = res.code;
        this.msg = res.msg;
    }
    getcode(){
        return this.code;
    }
    getmsg(){
        return this.msg;
    }
}