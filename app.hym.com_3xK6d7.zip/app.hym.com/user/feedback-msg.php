<div id="feedback-msg">
    
</div>
<div id="detail-box">
    <div class="head info">
        <div class="title">
            <span id="detail-box-thingname">默认</span>
        </div>
        <div class="closebtn">
            <span class="hymicon lq-cuocha_kuai"></span>
        </div>
    </div>
    <div class="body">
        <div class="itemline">
            <div class="item">
                <div class="icon">
                    <span class="hymicon lq-beizhu"></span>
                </div>
                <div class="content">
                    <div class="label">
                        <span>所属箱子</span>
                    </div>
                    <div class="value">
                        <span id="detail-box-classname">默认</span>
                    </div>
                </div>
            </div>
            <hr class="hr">
            <div class="item">
                <div class="icon">
                    <span class="hymicon lq-shijian"></span>
                </div>
                <div class="content">
                    <div class="label">
                        <span id="detail-box-type">过期天数</span>
                    </div>
                    <div class="value">
                        <span id="detail-box-ddlday">6天</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="itemline">
            <div class="item">
                <div class="icon">
                    <span class="hymicon lq-riqi2"></span>
                </div>
                <div class="content">
                    <div class="label">
                        <span>创建时间</span>
                    </div>
                    <div class="value">
                        <span id="detail-box-create">2022-04-23</span>
                    </div>
                </div>
            </div>
            <hr class="hr">
            <div class="item">
                <div class="icon">
                    <span class="hymicon lq-riqi2"></span>
                </div>
                <div class="content">
                    <div class="label">
                        <span>生产日期</span>
                    </div>
                    <div class="value">
                        <span id="detail-box-produce">2022-04-23</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="itemline">
            <div class="item">
                <div class="icon">
                    <span class="hymicon lq-yuanquan"></span>
                </div>
                <div class="content">
                    <div class="label">
                        <span>当前数量</span>
                    </div>
                    <div class="value">
                        <span id="detail-box-num">100</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="itemline">
            <div class="beizhu">
                <div class="icon">
                    <span class="hymicon lq-beizhu2"></span>
                </div>
                <div class="label">
                    <span>备注</span>
                </div>
            </div>
            <textarea readonly="true" id="detail-box-beizhu"></textarea>
        </div>
        <div class="btnbox">
            <div class="btn" id="thing_detail_edit" style="background-color:rgba(51,102,255,1);">
                <span>编辑</span>
            </div>
            <div class="btn" id="thing_detail_delete" style="background-color:rgba(255,51,51,1);">
                <span>删除</span>
            </div>
            <div class="btn" id="thing_detail_operator" style="background-color:rgba(238,140,20,1);">
                <span>处理</span>
            </div>
            <div class="btn" id="thing_detail_record" style="background-color:rgba(51,153,0,1);">
                <span>查看记录</span>
            </div>
        </div>
    </div>
</div>
<div class="shade" id="detail-shade"></div>