
<div id="mine-safe" class="minepannel">
    <div class="shade"></div>
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span>账号&安全</span>
        </div>
    </div>
    <div class="sets-box">
        <div class="card">
            <div class="item" id="open-edit-avatar">
                <div class="label-box">
                    <span>更改头像</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item" id="open-edit-name">
                <div class="label-box">
                    <span>更改昵称</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item" id="open-edit-password">
                <div class="label-box">
                    <span>更改密码</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="item" id="open-edit-email">
                <div class="label-box">
                    <span>邮箱绑定</span>
                    <span id="user_info_email" class="info">未绑定</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item" id="open-edit-phone">
                <div class="label-box">
                    <span>手机号绑定</span>
                    <span id="user_info_phone" class="info">未绑定</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="mine-help" class="minepannel">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span>帮助文档</span>
        </div>
    </div>
    <div class="sets-box">
        <div class="card">
            <div class="item" id="open-instruction">
                <div class="label-box">
                    <span>操作说明</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item" id="open-protocol">
                <div class="label-box">
                    <span>相关协议</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="mine-set" class="minepannel">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span>设置</span>
        </div>
    </div>
    <div class="sets-box">
        <!--<div class="card">-->
        <!--    <a class="item" id="feedback_qq">-->
        <!--        <div class="label-box">-->
        <!--            <span>问题反馈</span>-->
        <!--        </div>-->
        <!--        <div class="icon-box">-->
        <!--            <span class="hymicon lq-xiangyoujiantou"></span>-->
        <!--        </div>-->
        <!--    </a>-->
        <!--</div>-->
        <div class="card">
            <div class="item">
                <div class="label-switch-box">
                    <span>首页通知</span>
                </div>
                <div class="switch-box">
                    <div id="user_info_alert_inner" class="switch-out">
                        <div class="switch-in">
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="item">
                <div class="label-switch-box">
                    <span>邮箱通知</span>
                </div>
                <div class="switch-box">
                    <div id="user_info_alert_email" class="switch-out">
                        <div class="switch-in">
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="item">
                <div class="label-switch-box">
                    <span>短信通知</span>
                </div>
                <div class="switch-box">
                    <div id="user_info_alert_phone" class="switch-out">
                        <div class="switch-in">
                        </div>
                    </div>
                </div>
            </div>
            <!--<hr>
            <div class="item">
                <div class="label-switch-box">
                    <span>手机推送</span>
                </div>
                <div class="switch-box">
                    <div class="switch-out">
                        <div class="switch-in">
                        </div>
                    </div>
                </div>
            </div>-->
        </div>
        <!--<div class="card">
            <div class="item">
                <div class="label-box">
                    <span>清除缓存</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>-->
        <div class="card">
            <div class="item" id="open-softinfo">
                <div class="label-box">
                    <span>软件信息</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <!--<div class="item" id="open-about">-->
            <!--    <div class="label-box">-->
            <!--        <span>关于我们</span>-->
            <!--    </div>-->
            <!--    <div class="icon-box">-->
            <!--        <span class="hymicon lq-xiangyoujiantou"></span>-->
            <!--    </div>-->
            <!--</div>-->
        </div>
        <div class="card">
            <!--<div class="item">
                <div class="label-box">
                    <span>注销账号</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>-->
            <div class="item" id="open-exit">
                <div class="label-box">
                    <span>退出登录</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="edit-avatar" class="alert_panel">
    <div class="head-box">
        <div class="title">
            <span>更改头像</span>
        </div>
        <div class="return">
            <span class="hymicon lq-chacha2"></span>
        </div>
    </div>
    <div class="img-box">
        <img id="avatar-img" src=""/>
    </div>
    <div class="btn-box">
        <div class="btn" id="get_avatar">
            <span>上传图片</span>
        </div>
        <input type="file" name="file" id="file_img" accept="image/*" style="display:none;" onchange="chooseImg(this)" />
        <div id="edit-avatar-sub" class="btn">
            <span>确认更改</span>
        </div>
    </div>
</div>
<div id="edit-name" class="alert_panel">
    <div class="head-box">
        <div class="title">
            <span>更改昵称</span>
        </div>
        <div class="return">
            <span class="hymicon lq-chacha2"></span>
        </div>
    </div>
    <div class="input">
        <input type="text" id="edit_user_name" maxlength="16" placeholder="请输入新的昵称"/>
        <div class="clear-btn">
            <span class="hymicon lq-chahao1"></span>
        </div>
    </div>
    <div class="submit" id="sub_user_name">
        <span>确定</span>
    </div>
</div>
<div id="edit-password" class="alert_panel">
    <div class="head-box">
        <div class="title">
            <span>更改密码</span>
        </div>
        <div class="return">
            <span class="hymicon lq-chacha2"></span>
        </div>
    </div>
    <div class="input">
        <input id="edit_user_pwd_1" type="password" placeholder="请输入新密码"/>
        <div class="clear-btn">
            <span class="hymicon lq-chahao1"></span>
        </div>
    </div>
    <div class="input">
        <input id="edit_user_pwd_2" type="password" placeholder="请再次输入新密码"/>
        <div class="clear-btn">
            <span class="hymicon lq-chahao1"></span>
        </div>
    </div>
    <div class="submit" id="sub_user_pwd">
        <span>确定</span>
    </div>
</div>
<div id="edit-email" class="alert_panel">
    <div class="head-box">
        <div class="title">
            <span>更改邮箱绑定</span>
        </div>
        <div class="return">
            <span class="hymicon lq-chacha2"></span>
        </div>
    </div>
    <div class="input">
        <input type="text" id="edit-email-set" type="email" placeholder="请输入邮箱账号"/>
        <div class="clear-btn">
            <span class="hymicon lq-chahao1"></span>
        </div>
    </div>
    <div class="input code">
        <input type="text" id="edit-email-code" maxlength="6" placeholder="请输入验证码"/>
        <div class="get-btn" id="edit-email-get">
            <span>获取验证码</span>
        </div>
    </div>
    <div class="submit" id="sub_user_email">
        <span>确定</span>
    </div>
</div>
<div id="edit-phone" class="alert_panel">
    <div class="head-box">
        <div class="title">
            <span>更改手机绑定</span>
        </div>
        <div class="return">
            <span class="hymicon lq-chacha2"></span>
        </div>
    </div>
    <div class="input">
        <input type="text" maxlength="11" id="edit-phone-set" placeholder="请输入手机号"/>
        <div class="clear-btn">
            <span class="hymicon lq-chahao1"></span>
        </div>
    </div>
    <div class="input code">
        <input type="text" id="edit-phone-code" maxlength="6" placeholder="请输入验证码"/>
        <div class="get-btn" id="edit-phone-get">
            <span>获取验证码</span>
        </div>
    </div>
    <div class="submit" id="sub_user_phone">
        <span>确定</span>
    </div>
</div>
<div id="alert-clear" class="alert_panel">
    
</div>
<div id="logout" class="alert_panel">
    
</div>

<div id="mine-softinfo" class="minepannel">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span>软件信息</span>
        </div>
    </div>
    <div class="sets-box">
        <div class="card">
            <div class="item">
                <div class="label-box">
                    <span>软件版本号</span>
                    <span class="info">V1.0.5</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item">
                <div class="label-box">
                    <span>最近更新</span>
                    <span class="info">2024-01-01</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>
    </div>
</div>

<!--<div id="mine-about" class="minepannel">-->
<!--    <div class="head">-->
<!--        <div class="return-box">-->
<!--            <span class="hymicon lq-fanhui"></span>-->
<!--        </div>-->
<!--        <div class="title">-->
<!--            <span>关于我们</span>-->
<!--        </div>-->
<!--    </div>-->
<!--    <div class="sets-box">-->
<!--        <div class="card">-->
<!--            <div class="item">-->
<!--                <div class="label-box">-->
<!--                    <span>团队</span>-->
<!--                    <span class="info">好耶猫团队</span>-->
<!--                </div>-->
<!--                <div class="icon-box">-->
<!--                    <span class="hymicon lq-xiangyoujiantou"></span>-->
<!--                </div>-->
<!--            </div>-->
<!--            <hr>-->
<!--            <div class="item">-->
<!--                <div class="label-box">-->
<!--                    <span>公司</span>-->
<!--                    <span class="info">影小薯网络工作室</span>-->
<!--                </div>-->
<!--                <div class="icon-box">-->
<!--                    <span class="hymicon lq-xiangyoujiantou"></span>-->
<!--                </div>-->
<!--            </div>-->
<!--            <hr>-->
<!--            <div class="item">-->
<!--                <div class="label-box">-->
<!--                    <span>QQ群</span>-->
<!--                    <span class="info">951465481</span>-->
<!--                </div>-->
<!--                <div class="icon-box">-->
<!--                    <span class="hymicon lq-xiangyoujiantou"></span>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->