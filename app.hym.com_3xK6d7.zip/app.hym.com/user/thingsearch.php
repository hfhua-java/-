<div id="thingsearch-box">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span>物品查询</span>
        </div>
        <div class="open-searchbox">
            <span class="hymicon lq-chaxun5"></span>
        </div>
    </div>
    <div id="search-item-box">
        <div class="head">
            <div class="return-box">
                <span class="hymicon lq-you"></span>
            </div>
            <div class="title">
                <span>查询条件</span>
            </div>
        </div>
        <div class="item-box">
            <div class="item">
                <div class="title">
                    <span>物品名称:</span>
                </div>
                <div class="condition">
                    <input id="search-item-name" maxlength="50" placeholder="留空则为全部"/>
                </div>
            </div>
            <div class="item">
                <div class="title">
                    <span>类型筛选:</span>
                </div>
                <div class="condition">
                    <span id="searchlist_tag_1" class="safe tag">正常</span>
                    <span id="searchlist_tag_2" class="warn tag">临期</span>
                    <span id="searchlist_tag_3" class="danger tag">过期</span>
                </div>
            </div>
            <div class="item">
                <div class="title">
                    <span>分类选择:</span>
                </div>
                <div class="condition">
                    <div id="search-box-select">
                        <span class="hymicon lq-beizhu"></span>
                        <span class="text">默认</span>
                    </div>
                </div>
            </div>
            <div class="item">
                <div id="search-sub" class="submit">
                    <span>确定</span>
                </div>
            </div>
        </div>
    </div>
    <div id="search-box">
        <div class="statetag-box">
            <div class="multidel">
                <span class="hymicon lq-circleyuanquan"></span>
                <span>批量删除</span>
            </div>
        </div>
        <div class="list-box">
            <!--
            <div class="card-box">
                <div class="card">
                    <div class="head warn">
                        <div class="classname">
                            <span class="hymicon lq-beizhu"></span>
                            <span>默认</span>
                        </div>
                        <div class="days">
                            <span class="s">天</span>
                            <span>6</span>
                            <span class="s">距离过期还有</span>
                        </div>
                    </div>
                    <div class="body">
                        <div class="info">
                            <div class="topbox">
                                <div class="name">
                                    默认物品相关信息
                                </div>
                                <div class="num">
                                    <span>剩余:</span>
                                    <span>23</span>
                                </div>
                            </div>
                            <div class="bottombox">
                                <div class="time">
                                    2022-04-23
                                </div>
                                <div class="break"></div>
                                <div class="remark">
                                    默认物品相关信息
                                </div>
                            </div>
                        </div>
                        <div class="btnbox">
                            <div class="btn edit">
                                <span class="hymicon lq-beizhu- edit">编辑</span>
                            </div>
                            <div class="btn del">
                                <span class="hymicon lq-quancha del">删除</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="batch-box">
                    <input type="checkbox" />
                </div>
            </div>-->
            <div id="searchlist-loading-box" class="loading-boxes">
                <div class="icon">
                    <span class="hymicon lq-loading">
                </div>
                <div class="text">
                    <span>正在加载中··</span>
                </div>
            </div>
        </div>
        <div class="bacth">
            <div class="del">
                <span>删除</span>
            </div>
            <div class="cancel">
                <span>取消</span>
            </div>
        </div>
    </div>
    <div class="info">
        <!--<div class="spanbox">-->
        <!--    <span>共</span>-->
        <!--    <span>0</span>-->
        <!--    <span>条信息</span>-->
        <!--</div>-->
    </div>
    <div class="shade"></div>
</div>