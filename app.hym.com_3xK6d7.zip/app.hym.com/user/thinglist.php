<div id="thinglist-box">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span  id="appname">物品列表</span>
        </div>
        <div class="list_class" id="list_class_select">
            <span class="hymicon lq-beizhu"></span>
            <span class="name">全部</span>
        </div>
    </div>
    <div class="check-box">
        <div class="item">
            <span class="label">创建日期：</span>
            <!--还剩多久到期-->
            <!--几天内创建-->
            <!--该日期后到期-->
            <span class="value sift" id="thing-sift">不限-不限-不限</span>
            <span class="hymicon lq-xiala click"></span>
        </div>
        <div class="item">
            <span class="label">排序条件：</span>
            <!--创建时间-->
            <!--到期时间-->
            <!--二级升降序-->
            <span class="value sort" id="thing-sort">无排序</span>
            <span class="hymicon lq-xiala click"></span>
        </div>
    </div>
    <div class="statetag-box">
        <div class="multidel">
            <span class="hymicon lq-circleyuanquan"></span>
            <span>批量删除</span>
        </div>
        <div class="tag danger" id="thinglist_tag_1">
            <span>过期</span>
        </div>
        <div class="tag warn" id="thinglist_tag_2">
            <span>临期</span>
        </div>
        <div class="tag safe" id="thinglist_tag_3">
            <span>正常</span>
        </div>
    </div>
    <div class="list-box">
        <!--<div class="card-box">
            <div class="card">
                <div class="head safe">
                    <div class="classname">
                        <span class="hymicon lq-beizhu"></span>
                        <span>默认</span>
                    </div>
                    <div class="days">
                        <span class="s">天</span>
                        <span>6</span>
                        <span class="s">距离过期还有</span>
                    </div>
                </div>
                <div class="body">
                    <div class="info">
                        <div class="topbox">
                            <div class="name">
                                默认物品相关信息
                            </div>
                            <div class="num">
                                <span>剩余:</span>
                                <span>23</span>
                            </div>
                        </div>
                        <div class="bottombox">
                            <div class="time">
                                2022-04-23
                            </div>
                            <div class="break"></div>
                            <div class="remark">
                                默认物品相关信息
                            </div>
                        </div>
                    </div>
                    <div class="btnbox">
                        <div class="btn edit">
                            <span class="hymicon lq-beizhu- edit">编辑</span>
                        </div>
                        <div class="btn del">
                            <span class="hymicon lq-quancha del">删除</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="batch-box">
                <input type="checkbox" />
            </div>
        </div>-->
        <div id="thinglist-loading-box" class="loading-boxes">
            <div class="icon">
                <span class="hymicon lq-loading"></span>
            </div>
            <div class="text">
                <span>正在加载中··</span>
            </div>
        </div>
    </div>
    <div class="bacth">
        <div class="del">
            <span>删除</span>
        </div>
        <div class="cancel">
            <span>取消</span>
        </div>
    </div>
    <div class="info">
        <div class="spanbox">
            <span>共</span>
            <span id="thinglist_page_items"></span>
            <span>条信息</span>
        </div>
    </div>
    <!--<div class="detail-box">
        <div class="head danger">
            <div class="title">
                <span>默认物品</span>
            </div>
            <div class="closebtn">
                <span class="hymicon lq-cuocha_kuai"></span>
            </div>
        </div>
        <div class="body">
            <div class="itemline">
                <div class="item">
                    <div class="icon">
                        <span class="hymicon lq-beizhu"></span>
                    </div>
                    <div class="content">
                        <div class="label">
                            <span>所属箱子</span>
                        </div>
                        <div class="value">
                            <span>默认</span>
                        </div>
                    </div>
                </div>
                <hr class="hr">
                <div class="item">
                    <div class="icon">
                        <span class="hymicon lq-shijian"></span>
                    </div>
                    <div class="content">
                        <div class="label">
                            <span>过期天数</span>
                        </div>
                        <div class="value">
                            <span>6天</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="itemline">
                <div class="item">
                    <div class="icon">
                        <span class="hymicon lq-riqi2"></span>
                    </div>
                    <div class="content">
                        <div class="label">
                            <span>创建时间</span>
                        </div>
                        <div class="value">
                            <span>2022-04-23</span>
                        </div>
                    </div>
                </div>
                <hr class="hr">
                <div class="item">
                    <div class="icon">
                        <span class="hymicon lq-riqi2"></span>
                    </div>
                    <div class="content">
                        <div class="label">
                            <span>生产日期</span>
                        </div>
                        <div class="value">
                            <span>2022-04-23</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="itemline">
                <div class="item">
                    <div class="icon">
                        <span class="hymicon lq-yuanquan"></span>
                    </div>
                    <div class="content">
                        <div class="label">
                            <span>当前数量</span>
                        </div>
                        <div class="value">
                            <span>100</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="itemline">
                <div class="beizhu">
                    <div class="icon">
                        <span class="hymicon lq-beizhu2"></span>
                    </div>
                    <div class="label">
                        <span>备注</span>
                    </div>
                </div>
                <textarea readonly="true">备注的内容</textarea>
            </div>
            <div class="btnbox">
                <div class="btn" id="thinglist_detail_edit" style="background-color:rgba(51,102,255,1);">
                    <span>编辑</span>
                </div>
                <div class="btn" id="thinglist_detail_delete" style="background-color:rgba(255,51,51,1);">
                    <span>删除</span>
                </div>
                <div class="btn" id="thinglist_detail_operator" style="background-color:rgba(238,140,20,1);">
                    <span>处理</span>
                </div>
                <div class="btn" id="thinglist_detail_record" style="background-color:rgba(51,153,0,1);">
                    <span>查看记录</span>
                </div>
            </div>
        </div>
    </div>
    <div class="shade"></div>-->
</div>