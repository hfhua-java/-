<div class="pannel-body" id="pannel-index">
    <div class="pannel">
<!--概览部分-->
        <div class="title-box">
            <div class="title">
                <span class="hymicon lq-shujugailan"></span>
                <span>临期概览</span>
            </div>
        </div>
        <div id="thing_alert">
            <div class="tab-item">
                <div class="title">
                    <span class="type-safe hymicon lq-xianshizhengchang"></span>
                    <span>正常</span>
                </div>
                <div class="value">
                    <span class="type-safe"></span>
                </div>
            </div>
            <div class="tab-item">
                <div class="title">
                    <span class="type-warn hymicon lq-jinggao5"></span>
                    <span>临期</span>
                </div>
                <div class="value">
                    <span class="type-warn"></span>
                </div>
            </div>
            <div class="tab-item">
                <div class="title">
                    <span class="type-danger hymicon lq-quancha"></span>
                    <span>过期</span>
                </div>
                <div class="value">
                    <span class="type-danger"></span>
                </div>
            </div>
        </div>
        <div id="alert_info">
            <div id="tomorrow" class="list-box">
                <div class="title-box">
                    <div class="title">
                        <span class="type-warn hymicon lq-circleyuanquan"></span>
                        <span>明日过期</span>
                        <span class="magnify type-disable hymicon lq-fangda1"></span>
                    </div>
                </div>
                <div class="list">
                    <div class="swiper" id="tomorrowcard">
                        <div class="swiper-wrapper">
                            
                        </div>
                    </div>
                </div>
            </div>
            <div id="today" class="list-box">
                <div class="title-box">
                    <div class="title">
                        <span class="type-danger hymicon lq-circleyuanquan"></span>
                        <span>新增过期</span>
                        <span class="magnify type-disable hymicon lq-fangda1"></span>
                    </div>
                </div>
                <div class="list">
                    <div class="swiper" id="todaycard">
                        <div class="swiper-wrapper">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="magnify-box" id="biggerlist">
            <div class="title-box">
                <div class="title">
                    <!--样式变量-->
                    <span class="type-warn hymicon lq-circleyuanquan"></span>
                    <span class="name">查表变量</span>
                    <span class="shrink type-disable hymicon lq-suoxiao3"></span>
                </div>
            </div>
            <div class="list">
                <div id="alertinfo-loading-box" class="loading-boxes">
                    <div class="icon">
                        <span class="hymicon lq-loading"></span>
                    </div>
                    <div class="text">
                        <span>正在加载中··</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="shade"></div>
        <!--快捷入口部分-->
        <div class="title-box">
            <div class="title">
                <span class="hymicon lq-kuaijie"></span>
                <span>快捷入口</span>
            </div>
        </div>
        <div id="button">
            <div class="tab-item">
                <div class="title">
                    <span>添加新物品</span>
                </div>
                <div class="btn-item"  id="quickentry-1">
                    <span class="type-safe hymicon lq-tianjia4"></span>
                </div>
            </div>
            <div class="tab-item">
                <div class="title">
                    <span>列表查看</span>
                </div>
                <div class="btn-item" id="quickentry-2">
                    <span class="type-normal hymicon lq-liebiao1"></span>
                </div>
            </div>
            <div class="tab-item" id="quickentry-3">
                <div class="title">
                    <span>查询物品</span>
                </div>
                <div class="btn-item">
                    <span class="type-disable hymicon lq-chaxun4"></span>
                </div>
            </div>
        </div>
    </div>
</div>